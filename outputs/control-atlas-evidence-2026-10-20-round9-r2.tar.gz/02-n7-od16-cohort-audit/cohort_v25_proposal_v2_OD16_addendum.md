# Cohort v25 Proposal — OD-16 Metadata-Reconciliation Addendum (document version 2)

**Status:** PROPOSAL ONLY. Nothing here is executed, merged, or frozen. The hard
stop remains in force: no calibration, held-out evaluation, threshold change,
cohort change, or golden-artifact regeneration is authorized by this document.

**Lineage:**
- Document version 1: `backend/calibration/protocol/cohort_v25_proposal.md`
  @ `science/p0-correctness-2026-10-19`, blob
  `4362e7d372b47851691b90823cefe05b6f329ecb` (P0 item 16 prep; all numeric
  criteria owner-gated). Version 1 remains untouched on the remote branch.
- Document version 2 (this file): OD-16 addendum required by the
  auditor-adjudicated disposition of 2026-10-20 (Round 9, direction 2). It
  extends — never rewrites — version 1 with the full item-level metadata
  reconciliation. It is delivered as an evidence-bundle document, not as a
  repository commit (no push is authorized).

## 1. Grounds for this addendum (what changed since version 1)

Version 1 identified 1I0T as mislabeled ("Ferredoxin"; actually Z-DNA) and
flagged resolution-provenance inconsistency. The Round-9 audit — auditor
corroboration on four entries (1EJG, 3NIR, 1I0T, 2VB1) plus a fresh
source-backed check of all 40 experimental targets this session — establishes
that the metadata defect is **cohort-wide, not isolated**:

- 22/40 recorded descriptions make incorrect claims (21 different-molecule,
  1 contradicted ligation state);
- 5/40 wrong method class; 24/40 wrong resolution (23/40 beyond 0.01 Å);
- 2/40 acquired structures are not protein-only (1I0T DNA; 1DDL virus +
  RNA);
- 0/40 coordinate-byte mismatches vs the v24 manifest (acquisition is stable;
  the labels are wrong).

Item-level evidence: `n7_od16_40target_table.{md,json}`, `rcsb-api/`,
`N7_OD16_DISCREPANCY_REPORT.md` (same directory).

## 2. Binding principle (supersedes nothing, extends everything)

**No field of the v23 cohort metadata (`desc`, `resolution`, category/method
labels) may be trusted or copied into any future cohort. Every annotation
must be re-derived from official RCSB/AFDB records at build time and pinned
by digest.** Version 1 §1 already stated this for resolution values ("the v25
cohort must re-derive every annotation from wwPDB/RCSB metadata"); this
addendum extends it to descriptions, methods, and entity identity, with
row-level evidence that the defect class is general.

Quarantine (OD-16): until an owner-approved reconciliation exists, the v23
cohort metadata is not valid input for calibration, threshold selection,
stratification, or eligibility decisions. The historical files and results are
preserved unchanged (verified this session: pinned blobs intact on the remote).

## 3. Per-entry disposition framework (owner decisions, NOT ad-hoc selection)

For each of the 40 experimental entries, the reconciliation table establishes
what was *recorded* and what was *actually acquired*. Dispositions fall into
four classes. **This document selects none of them; it records the decision
each entry requires.**

### Class A — clean entries (8): 1AKE, 1AON, 1D3Z, 1GB1, 1GFL, 2JOF, 2LYZ, 3LZM
Recorded metadata matches official records across C1/C2/C3. Still subject to
version 1's quality filter (resolution ≤ [owner], R-free, completeness,
PISCES culling, validation-report gates) before inclusion in v25. No
metadata-specific owner decision required.

### Class B — correct molecule, wrong numeric/method annotation (9)
1BPI (1.10 vs 1.09, rounding-level), 1BRS, 1FIN, 1MBO, 1TEN, 2ACE, 2CBA,
2HBS, 3PGK (derived from the table: resolution-mismatch rows whose recorded
description matches).
Disposition is mechanical once the §2 principle is applied: re-derive the
annotation from RCSB; the structure itself was the recorded intent. Owner
decision required only on whether the *corrected* values still satisfy the
version-1 quality filter (e.g., 2ACE at 2.5 Å fails a ≤ 2.0 Å default).

### Class C — wrong molecule acquired; recorded intent identifiable (18)
The coordinate bytes belong to a different structure than the recorded
description names:

| PDB | Recorded intent | Actually acquired (official) | Decision required |
|---|---|---|---|
| 1EJG | Cholesterol oxidase | Crambin 0.54 Å | keep crambin (corrected label) or re-acquire intended target |
| 2OV0 | Lysozyme ultra-high | Amicyanin 0.75 Å | same choice |
| 2VB1 | Crambin 0.48 Å | HEWL 0.65 Å | same choice |
| 3NIR | Concanavalin A 1.00 Å | Crambin 0.48 Å | same choice |
| 1GCI | Glucose isomerase 1.10 Å | *B. lentus* subtilisin 0.78 Å | same choice |
| 1NEK | Nek2 kinase 2.80 Å | succinate dehydrogenase 2.6 Å | same choice |
| 1L2Y | Villin headpiece | Trp-cage TC5b | same choice |
| 2KOX | GB1 domain | Ubiquitin | same choice |
| 2MJB | Amyloid beta | Ubiquitin(-L40) | same choice |
| 1RVS | BPTI | Transthyretin fibrils (ssNMR) | same choice + NMR-subclass policy |
| 3J9I | 80S ribosome | 20S proteasome | same choice |
| 5A63 | TRPV1 | γ-secretase | same choice |
| 5T4O | Spliceosome 3.4 Å | ATP synthase 6.9 Å | same choice |
| 6J6J | 26S proteasome | Streptavidin | same choice |
| 6NB6 | ABC transporter | SARS-CoV + S230 Fab | same choice |
| 6WLC | Nucleocapsid (cryo-EM 2.9) | NSP15 endoribonuclease (X-ray 1.82) | same choice + method-stratum reassignment |
| 7JTL | RBD-ACE2 (cryo-EM 2.3) | ORF8 (X-ray 2.04) | same choice + method-stratum reassignment |
| 1PPE | Porcine elastase | Bovine β-trypsin + CMTI-I | same choice |

(18 rows listed — the 21 identity errors minus 1DDL, 1I0T and 7K3G, which are
Class D. 1PPE carries both an identity error and a resolution error
(recorded 1.80 Å vs official 2.0 Å); it is Class C.) For every row the owner
chooses among:
**(a)** keep the actually-acquired structure with the corrected RCSB-derived
annotation; **(b)** re-acquire the recorded intent (a *new* target selection,
subject to the version-1 quality filter and to the no-circularity rule); or
**(c)** drop the slot. Selecting (b) requires recording the replacement
criterion — not an ad-hoc pick — per the OD-16 direction.

### Class D — eligibility violations, state errors, and method-subclass policy (5)
- **1I0T** (Z-DNA, nucleic-acid-only): REMOVE from a protein-only protocol —
  version 1 §1 already records two independent grounds. Re-inclusion would
  require the protocol to explicitly cover nucleic-acid structures and define
  applicable laws for them (none exist in the pinned governance documents).
- **1DDL** (tymovirus, protein + RNA): ineligible by default for protein-only;
  owner must define assembly-eligibility criteria before any disposition.
- **1HHO** (oxyhaemoglobin recorded as deoxy): state error; disposition is the
  Class-C choice (keep corrected vs re-acquire a true deoxy-Hb entry).
- **7K3G** (envelope-protein TMD pentamer, solid-state NMR, recorded as
  cryo-EM spike at 2.60 Å): identity error + method error; Class-C choice
  plus the NMR-subclass and method-stratum policy decision.
- **2N0A** (α-synuclein fibrils, solid-state NMR, recorded under solution-NMR
  category): molecule correct, method subclass wrong; needs the same
  NMR-subclass policy decision (fibrillar/solid-state entries: separate
  stratum, exclusion, or inclusion with defined semantics).

### Predicted stratum
Version 1's dispositions stand unchanged: AF-P0DTC2-F1 (migrated entity
AF-0000000365840314; follow-or-replace is an owner decision), AF-P62988-F1
(UniProt Inactive; remove, ground recorded). The remaining eight AFDB targets
acquired successfully in the corrected pipeline (metadata-first lookup) per
P0 items 11–14; their identity/acquisition records are preserved as required
by the P0DTC2/P62988 decision area (see `04-decisions/OWNER_DECISIONS.md`).

## 4. Additional owner decisions surfaced by this addendum

1. **NMR subclass policy:** solution vs solid-state vs fibrillar entries —
   separate strata, exclusion, or inclusion (affects 1RVS, 2N0A, 7K3G).
2. **Method-stratum reassignment rule:** entries whose true method differs
   from the recorded category (6WLC, 7JTL X-ray; 7K3G ssNMR) move strata when
   corrected — confirm strata remain adequately populated (version 1's
   ≥ 15-per-stratum minimum may fail for cryo-EM after correction: of the 8
   recorded cryo-EM entries, only 5 are actually electron microscopy (3J9I,
   5A63, 5T4O, 6J6J, 6NB6); 6WLC and 7JTL are X-ray; 7K3G is solid-state NMR).
3. **Duplicate-awareness rule:** after correction, 2KOX and 2MJB are both
   ubiquitin (and 1D3Z is also ubiquitin) — three ubiquitin entries in a
   40-entry cohort violates diversity intent; the PISCES-style culling in
   version 1 §2 must be identity-aware at the *corrected* annotation level.
4. **Stratification rebuild:** with 32/40 rows carrying at least one metadata
   defect, the recorded strata (ultrahigh/medium/low/cryo-EM/NMR) cannot be
   treated as valid stratification for any future analysis; they must be
   rebuilt from corrected annotations before any statistical use.

## 5. What this addendum explicitly does NOT do

- It does not modify `dataset_v23.py`, the v23 results, the v24 run artifacts,
  or any remote branch (verified untouched; no push performed or possible).
- It does not select any replacement structure, drop any entry, or set any
  numeric criterion — every such action is owner-gated (version 1 §2, §4).
- It does not authorize v25 execution: the version-1 order of operations
  (owner criteria → cohort build + digest pinning → held-out split committed
  before measurement → v25 diagnostic run → threshold derivation) remains
  binding, and the OD-16 quarantine blocks all of it until the
  reconciliation above is approved.

## 6. Reproduction

All facts cited here derive from `n7_od16_40target_table.json` (40 rows,
script-derived totals, per-row rationale) and the bundled raw RCSB evidence.
Re-derive with `reproduce-clean-checkout.sh` (bundle root) or the scripts in
`09-scripts/`.
