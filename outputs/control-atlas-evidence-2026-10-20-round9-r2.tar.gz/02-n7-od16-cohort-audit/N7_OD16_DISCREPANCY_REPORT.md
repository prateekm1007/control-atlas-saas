# OD-16 Cohort-Metadata Discrepancy Report and Quarantine Disposition

**Status:** AUDITOR-ADJUDICATED disposition implemented as documentation; diagnostic only.
**Generated UTC:** 2026-10-19T20:30Z (approx.) · **Coder session:** Round 9.
**Pinned source:** `backend/calibration/dataset_v23.py` @ blob
`3a5358374b2037b9475bd2d494754944485da5ac` (branch
`science/p0-correctness-2026-10-19`, tip `ebc1fd79f20b9a6b6a262a70ce6942ba069d19e9`).

## 1. Finding (material cohort-integrity defect)

The auditor independently inspected the remote `dataset_v23.py` and confirmed
four examples of incorrect recorded metadata against official RCSB records
(1EJG, 3NIR, 1I0T, 2VB1). This session re-verified those four examples against
the live RCSB Data API and extended the check to **all 40 experimental
targets**. The result: the recorded cohort metadata is materially defective at
scale. Under the documented classification rules (see
`n7_od16_40target_table.md`):

- **22/40** entries carry an incorrect descriptive claim (21 name a different
  molecular system; 1 asserts a contradicted ligation state).
- **5/40** record the wrong experimental method class (three solid-state NMR
  structures recorded under a solution-NMR category; two X-ray structures
  recorded under cryo-EM).
- **24/40** record a resolution inconsistent with the official value (23/40 if
  differences of exactly 0.01 Å are treated as rounding-level).
- **2/40** acquired structures are not protein-only (1I0T is a Z-DNA hexamer —
  nucleic acid only; 1DDL is a tymovirus particle containing protein + RNA).
- **0/40** coordinate files differ by a single byte from the historical v24
  manifest digests — the defect is exclusively in the recorded *metadata*, not
  in the acquired coordinate bytes.
- **0/40** files failed PDB record-level parsing this session.
- Net: only **8/40** rows are fully clean across C1∪C2∪C3 (1AKE, 1AON, 1D3Z,
  1GB1, 1GFL, 2JOF, 2LYZ, 3LZM); **32/40** have at least one metadata defect.

Notable identity errors beyond the auditor's four examples include 1PPE
(recorded "Porcine elastase"; official structure is bovine β-trypsin complexed
with the CMTI-I squash-seed inhibitor), 2KOX (recorded "GB1 domain NMR";
official entity is ubiquitin), 2MJB (recorded "Amyloid beta NMR"; official
entity is ubiquitin), 1GCI (recorded "Glucose isomerase" at 1.10 Å; official
structure is a *B. lentus* subtilisin at 0.78 Å), 5T4O (recorded "Spliceosome"
at 3.40 Å; official structure is *E. coli* ATP synthase at 6.9 Å), and 6WLC /
7JTL / 7K3G (three SARS-CoV-2 structures recorded with the wrong protein,
wrong method, or both).

## 2. Auditor-adjudicated disposition (OD-16), as directed

> Quarantine the v23 cohort metadata for calibration and threshold-selection
> purposes pending a complete source-backed reconciliation. Preserve the
> historical `dataset_v23.py` and its original results unchanged. Create a
> versioned corrected cohort proposal and discrepancy report; do not silently
> rewrite history or select replacements ad hoc.

Implementation in this deliverable:

1. **Quarantine (in effect):** the hard stop already forbids calibration,
   threshold selection, held-out evaluation, and golden-artifact regeneration.
   This report additionally records that the v23 cohort *metadata* — the
   category labels, descriptions, and resolutions in `dataset_v23.py` — is
   **not valid input for any calibration, threshold-selection, stratification,
   or eligibility decision** until a source-backed reconciliation is completed
   and approved by the owner. The v23 *coordinate bytes* remain what they are
   (byte-identical to the v24 manifest), but byte-stability does not confer
   scientific appropriateness: correct bytes for the wrong-labeled structures
   still produce a mislabeled cohort.
2. **Historical preservation (verified this session):** `dataset_v23.py` is
   byte-preserved at the pinned blob on the remote branch (re-verified);
   `backend/calibration/calibration_results.json` and the v24 run artifacts
   (`runs/v24/*`, including the SUPERSEDED marker) are untouched on the
   remote. No commit, push, or file modification was performed in this
   session; all work products are new documents in this evidence bundle.
3. **Versioned corrected cohort proposal:** delivered as
   `cohort_v25_proposal_OD16.md` in this directory — a *proposal only*, with
   every replacement decision owner-gated. It does not modify the dataset and
   does not select replacements ad hoc; where the official identity differs
   from the recorded intent, it records both and leaves the disposition open.
4. **This discrepancy report** is the item-level record the disposition
   requires: for every experimental target it records the official RCSB title,
   polymer/entity identity, experimental method, resolution, source revision
   date, downloaded coordinate digest (fresh and v24), and the value recorded
   in the dataset (see `n7_od16_40target_table.{md,json}` and `rcsb-api/`).

## 3. Protein-vs-nucleic-acid mismatch (explicit flag)

- **1I0T** — recorded as "Ferredoxin" (a protein) at 0.89 Å; the official
  structure is **Z-DNA (CGCGCG) at 0.60 Å**, polymer composition *DNA only*,
  zero protein entities. **1I0T must not count as a protein-only calibration
  target.** Its inclusion would require the protocol to explicitly cover
  nucleic-acid structures and to define which laws apply to them; no such
  protocol text exists in the pinned governance documents.
- **1DDL** — recorded as "Dihydroorotase" at 3.50 Å; the official structure is
  **Desmodium yellow mottle tymovirus** at 2.7 Å, a virus particle with one
  polypeptide entity and two RNA entities. Ineligible by default for a
  protein-only protocol pending explicit owner criteria for assemblies
  containing nucleic acids.
- Fibrillar/solid-state entries (1RVS transthyretin fibrils, 2N0A
  α-synuclein fibrils, 7K3G envelope-protein TMD pentamer) are protein-only
  in entity terms but deviate from the recorded method class; they are
  recorded as method mismatches, not eligibility exclusions.

## 4. What this report does NOT do

- It does not approve, reject, or modify any structure's membership in a
  future cohort (owner-gated; see `cohort_v25_proposal_OD16.md`).
- It does not re-run any Toscanini measurement, verdict, calibration, or
  threshold selection (hard stop in effect; measurement-level columns of the
  historical N7 comparison remain `CODER_REPORTED` — see
  `03-n7-comparison/`).
- It does not claim the 40 coordinate inputs are scientifically appropriate
  merely because their bytes match the historical v24 manifest. Byte equality
  is reported as a *software/acquisition-stability* fact only.
- It does not modify the historical `dataset_v23.py`, its results, or any
  remote branch.

## 5. Evidence and reproduction

- Raw RCSB Data API responses (entry + polymer entities, all 40):
  `rcsb-api/*.json` (each file's SHA-256 recorded in
  `n7_od16_40target_table.json` per row).
- Exemplar coordinate files for the four auditor-corroborated cases:
  `coordinates-exemplars/{1EJG,3NIR,1I0T,2VB1}.pdb` (all 40 fresh digests are
  in the JSON table; the bundled verifier re-downloads and re-hashes all 40).
- Generation scripts (read the code before trusting the output):
  `09-scripts/rcsb_cohort_audit.py` (fetch + parse + digest), `09-scripts/
  fix_parse_pass.py` (documented fix pass: EXPDTA record-name width,
  `polymer_entity_count_DNA` case-sensitive API key), `09-scripts/
  adjudicate_table.py` (classification rules + totals derived from rows),
  `09-scripts/render_table_md.py`.
- Clean-checkout reproduction: `reproduce-clean-checkout.sh` at the bundle
  root re-clones the repository, verifies the pinned blobs, re-fetches the
  RCSB evidence, and re-derives the table.

## 6. Provenance of the "20/40" and "23/40" transcript figures (CORRECTED, Round 10 / T5)

**Correction.** The r1 version of this section treated the transcript's
"20/40" as a description-mismatch count. The auditor has corrected the
provenance (Round 10, T5): **"at most 20 of 40 experimental structures
could pass" was the auditor's own earlier bound, derived without
recomputing.** The tracked artifact
`docs/audit-evidence/2026-10-19/science-validity/independent_recompute_20_of_40.json`
(blob `6cda70e2791d50325643e8fbbf56db7ee9948f8d` @
`science/p0-correctness-2026-10-19`, `ebc1fd7`) shows the actual figure:
**0 of 40** could pass under the recorded v23 rows and the current modality
matrix — 38 blocked by LAW-120 at 10°, 2 by LAW-170 (1I0T and 1DDL). Both
figures (the bound and the 0/40) describe the **recorded v23 run** and are
**historical**. "20 of 40" no longer appears anywhere in this bundle as a
pass-eligibility figure.

The "23/40" figure stands as reported: the fresh, row-derived resolution
mismatch at 0.01 Å tolerance is exactly **23/40** (24/40 strict; the two
comparisons are always reported independently). The prior session's logs
and scripts are lost (sandbox reset; see `08-lost-work-statement/`), so the
transcript figures remain `CODER_REPORTED` where they are not re-derived
here. The full derivation, the 0/40 correction, and the row-by-row
comparison are in `COUNT_RECONCILIATION_ALL_CLAIMS.md` (which supersedes
the r1 `20-40_vs_23-40_RECONCILIATION.md`, preserved inside the r1
archive).
