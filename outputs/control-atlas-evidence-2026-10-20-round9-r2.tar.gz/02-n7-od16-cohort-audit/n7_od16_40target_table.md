# N7 / OD-16 — Item-Level Discrepancy Table, All 40 Experimental Structures

Generated UTC: 2026-10-19T20:06:58.725502+00:00 · dataset_v23.py blob `3a5358374b2037b9475bd2d494754944485da5ac`

All rows derive from fresh, this-session evidence: RCSB Data API entry/polymer-entity
responses and coordinate downloads from `https://files.rcsb.org/download/{id}.pdb`
(raw responses bundled in `rcsb-api/`, digests in the JSON table). Counts are derived
from these rows by script (`09-scripts/adjudicate_table.py`). No calibration, threshold
derivation, verdict issuance, cohort change, or golden-artifact regeneration was performed.

## Column definitions

| Column | Definition |
|---|---|
| C1 desc | `identity_error` = recorded `desc` names a different molecular system than the official RCSB structure; `state_error` = recorded desc asserts a contradicted ligation/assembly state; `match` = same system, no false specific claim |
| C2 method | recorded category-implied method (xray→X-RAY DIFFRACTION, cryo_em→ELECTRON MICROSCOPY, nmr→SOLUTION NMR) vs official EXPDTL method |
| C2 res | recorded `resolution` vs official `resolution_combined[0]`; strict: \|Δ\|>0.005 Å; tol: \|Δ\|>0.01 Å |
| C3 entity | polymer entity class of the ACTUAL acquired structure vs a protein-only calibration protocol |
| C4 parse | PDB record-level parse failures this session (parse anomalies recorded in JSON, informational) |
| C5 bytes | SHA-256 of fresh coordinate download vs `backend/calibration/runs/v24/coordinate_manifest.json` recorded digest |

## Totals (derived from the rows below)

- Experimental targets: **40**
- C1 descriptive errors: **22/40** (21 identity + 1 ligation-state)
- C2 method mismatches: **5/40**; resolution mismatches: **24/40 strict**, **23/40** at 0.01 Å tolerance; combined method-or-resolution: **26/40 strict** / **25/40 tolerant**
- C3 entity eligibility flags: **2/40** (1 nucleic-acid-only: 1I0T; 1 protein+RNA virus particle: 1DDL)
- C4 parse failures: **0/40** (measurement-level re-run NOT performed — hard stop; historical N7 measurement logs lost)
- C5 coordinate-byte mismatches vs v24 manifest: **0/40**
- Rows with ≥1 metadata defect (C1∪C2∪C3): **32/40**; fully clean: **8** (1AKE, 1AON, 1D3Z, 1GB1, 1GFL, 2JOF, 2LYZ, 3LZM)

## Item-level table (40 rows)

| # | PDB | Recorded category | Recorded desc (dataset_v23.py) | Official RCSB title | Official method | Res rec→off (Å) | C1 desc | C2 method | C2 res | C3 entity | C4 parse | C5 bytes |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | 1AKE | xray_medium | Adenylate kinase | STRUCTURE OF THE COMPLEX BETWEEN ADENYLATE KINASE FROM ESCHERICHIA COLI AND THE INHIBITOR AP5A  | X-RAY DIFFRACTION | 2.0→2.0 | ok | ok | ok | protein_only | ok | match |
| 2 | 1AON | xray_low | GroEL-GroES complex | CRYSTAL STRUCTURE OF THE ASYMMETRIC CHAPERONIN COMPLEX GROEL/GROES/(ADP)7 | X-RAY DIFFRACTION | 3.0→3.0 | ok | ok | ok | protein_only | ok | match |
| 3 | 1BPI | xray_ultrahigh | BPTI | THE STRUCTURE OF BOVINE PANCREATIC TRYPSIN INHIBITOR AT 125K: DEFINITION OF CARBOXYL-TERMINAL R | X-RAY DIFFRACTION | 1.1→1.09 | ok | ok | rm01 | protein_only | ok | match |
| 4 | 1BRS | xray_low | Barnase-barstar | PROTEIN-PROTEIN RECOGNITION: CRYSTAL STRUCTURAL ANALYSIS OF A BARNASE-BARSTAR COMPLEX AT 2.0-A  | X-RAY DIFFRACTION | 2.8→2.0 | ok | ok | **RM** | protein_only | ok | match |
| 5 | 1D3Z | nmr | Ubiquitin NMR | UBIQUITIN NMR STRUCTURE | SOLUTION NMR | None→None | ok | ok | ok | protein_only | ok | match |
| 6 | 1DDL | xray_low | Dihydroorotase | DESMODIUM YELLOW MOTTLE TYMOVIRUS | X-RAY DIFFRACTION | 3.5→2.7 | **IDENT** | ok | **RM** | INELIGIBLE_BY_DEFAULT_pending_criteria | ok | match |
| 7 | 1EJG | xray_ultrahigh | Cholesterol oxidase | CRAMBIN AT ULTRA-HIGH RESOLUTION: VALENCE ELECTRON DENSITY. | X-RAY DIFFRACTION | 0.54→0.54 | **IDENT** | ok | ok | protein_only | ok | match |
| 8 | 1FIN | xray_low | CDK2-cyclin A | CYCLIN A-CYCLIN-DEPENDENT KINASE 2 COMPLEX | X-RAY DIFFRACTION | 2.8→2.3 | ok | ok | **RM** | protein_only | ok | match |
| 9 | 1GB1 | nmr | Protein G B1 NMR | A NOVEL, HIGHLY STABLE FOLD OF THE IMMUNOGLOBULIN BINDING DOMAIN OF STREPTOCOCCAL PROTEIN G | SOLUTION NMR | None→None | ok | ok | ok | protein_only | ok | match |
| 10 | 1GCI | xray_ultrahigh | Glucose isomerase | THE 0.78 ANGSTROMS STRUCTURE OF A SERINE PROTEASE-BACILLUS LENTUS SUBTILISIN | X-RAY DIFFRACTION | 1.1→0.78 | **IDENT** | ok | **RM** | protein_only | ok | match |
| 11 | 1GFL | xray_medium | GFP | STRUCTURE OF GREEN FLUORESCENT PROTEIN | X-RAY DIFFRACTION | 1.9→1.9 | ok | ok | ok | protein_only | ok | match |
| 12 | 1HHO | xray_medium | Deoxyhemoglobin | STRUCTURE OF HUMAN OXYHAEMOGLOBIN AT 2.1 ANGSTROMS RESOLUTION | X-RAY DIFFRACTION | 2.1→2.1 | **STATE** | ok | ok | protein_only | ok | match |
| 13 | 1I0T | xray_ultrahigh | Ferredoxin | 0.6 A STRUCTURE OF Z-DNA CGCGCG | X-RAY DIFFRACTION | 0.89→0.6 | **IDENT** | ok | **RM** | INELIGIBLE_protein_only | ok | match |
| 14 | 1L2Y | nmr | Villin headpiece NMR | NMR Structure of Trp-Cage Miniprotein Construct TC5b | SOLUTION NMR | None→None | **IDENT** | ok | ok | protein_only | ok | match |
| 15 | 1MBO | xray_medium | Myoglobin | Structure and refinement of oxymyoglobin at 1.6 angstroms resolution | X-RAY DIFFRACTION | 2.0→1.6 | ok | ok | **RM** | protein_only | ok | match |
| 16 | 1NEK | xray_low | Nek2 kinase | Complex II (Succinate Dehydrogenase) From E. Coli with ubiquinone bound | X-RAY DIFFRACTION | 2.8→2.6 | **IDENT** | ok | **RM** | protein_only | ok | match |
| 17 | 1PPE | xray_medium | Porcine elastase | THE REFINED 2.0 ANGSTROMS X-RAY CRYSTAL STRUCTURE OF THE COMPLEX FORMED BETWEEN BOVINE BETA-TRY | X-RAY DIFFRACTION | 1.8→2.0 | **IDENT** | ok | **RM** | protein_only | ok | match |
| 18 | 1RVS | nmr | BPTI NMR | STRUCTURE OF TRANSTHYRETIN IN AMYLOID FIBRILS DETERMINED BY SOLID-STATE MAGIC ANGLE SPINNING NM | SOLID-STATE NMR | None→None | **IDENT** | **MM** | ok | protein_only | ok | match |
| 19 | 1TEN | xray_medium | Tenascin | STRUCTURE OF A FIBRONECTIN TYPE III DOMAIN FROM TENASCIN PHASED BY MAD ANALYSIS OF THE SELENOME | X-RAY DIFFRACTION | 1.6→1.8 | ok | ok | **RM** | protein_only | ok | match |
| 20 | 2ACE | xray_ultrahigh | Acetylcholinesterase | NATIVE ACETYLCHOLINESTERASE (E.C. 3.1.1.7) FROM TORPEDO CALIFORNICA | X-RAY DIFFRACTION | 1.1→2.5 | ok | ok | **RM** | protein_only | ok | match |
| 21 | 2CBA | xray_medium | Carbonic anhydrase | STRUCTURE OF NATIVE AND APO CARBONIC ANHYDRASE II AND SOME OF ITS ANION-LIGAND COMPLEXES | X-RAY DIFFRACTION | 2.0→1.54 | ok | ok | **RM** | protein_only | ok | match |
| 22 | 2HBS | xray_low | Sickle cell hemoglobin | THE HIGH RESOLUTION CRYSTAL STRUCTURE OF DEOXYHEMOGLOBIN S | X-RAY DIFFRACTION | 2.5→2.05 | ok | ok | **RM** | protein_only | ok | match |
| 23 | 2JOF | nmr | Trp-cage miniprotein NMR | The Trp-cage: Optimizing the Stability of a Globular Miniprotein | SOLUTION NMR | None→None | ok | ok | ok | protein_only | ok | match |
| 24 | 2KOX | nmr | GB1 domain NMR | NMR residual dipolar couplings identify long range correlated motions in the backbone of the pr | SOLUTION NMR | None→None | **IDENT** | ok | ok | protein_only | ok | match |
| 25 | 2LYZ | xray_medium | Hen lysozyme | Real-space refinement of the structure of hen egg-white lysozyme | X-RAY DIFFRACTION | 2.0→2.0 | ok | ok | ok | protein_only | ok | match |
| 26 | 2MJB | nmr | Amyloid beta NMR | Solution nmr structure of ubiquitin refined against dipolar couplings in 4 media | SOLUTION NMR | None→None | **IDENT** | ok | ok | protein_only | ok | match |
| 27 | 2N0A | nmr | Alpha-synuclein NMR | Atomic-resolution structure of alpha-synuclein fibrils | SOLID-STATE NMR | None→None | ok | **MM** | ok | protein_only | ok | match |
| 28 | 2OV0 | xray_ultrahigh | Lysozyme ultra-high | Structure of the blue copper protein Amicyanin to 0.75 A resolution | X-RAY DIFFRACTION | 0.75→0.75 | **IDENT** | ok | ok | protein_only | ok | match |
| 29 | 2VB1 | xray_ultrahigh | Crambin ultra-high res | HEWL at 0.65 angstrom resolution | X-RAY DIFFRACTION | 0.48→0.65 | **IDENT** | ok | **RM** | protein_only | ok | match |
| 30 | 3J9I | cryo_em | 80S ribosome | Thermoplasma acidophilum 20S proteasome | ELECTRON MICROSCOPY | 3.6→3.3 | **IDENT** | ok | **RM** | protein_only | ok | match |
| 31 | 3LZM | xray_medium | T4 lysozyme | STRUCTURAL STUDIES OF MUTANTS OF T4 LYSOZYME THAT ALTER HYDROPHOBIC STABILIZATION | X-RAY DIFFRACTION | 1.7→1.7 | ok | ok | ok | protein_only | ok | match |
| 32 | 3NIR | xray_ultrahigh | Concanavalin A | Crystal structure of small protein crambin at 0.48 A resolution | X-RAY DIFFRACTION | 1.0→0.48 | **IDENT** | ok | **RM** | protein_only | ok | match |
| 33 | 3PGK | xray_medium | Phosphoglycerate kinase | The structure of yeast phosphoglycerate kinase at 0.25 nm resolution | X-RAY DIFFRACTION | 2.1→2.5 | ok | ok | **RM** | protein_only | ok | match |
| 34 | 5A63 | cryo_em | TRPV1 channel | Cryo-EM structure of the human gamma-secretase complex at 3.4 angstrom resolution. | ELECTRON MICROSCOPY | 2.8→3.4 | **IDENT** | ok | **RM** | protein_only | ok | match |
| 35 | 5T4O | cryo_em | Spliceosome | Autoinhibited E. coli ATP synthase state 1 | ELECTRON MICROSCOPY | 3.4→6.9 | **IDENT** | ok | **RM** | protein_only | ok | match |
| 36 | 6J6J | cryo_em | Human 26S proteasome | Biotin-bound streptavidin | ELECTRON MICROSCOPY | 2.2→3.2 | **IDENT** | ok | **RM** | protein_only | ok | match |
| 37 | 6NB6 | cryo_em | ABC transporter | SARS-CoV complex with human neutralizing S230 antibody Fab fragment (state 1) | ELECTRON MICROSCOPY | 3.0→4.2 | **IDENT** | ok | **RM** | protein_only | ok | match |
| 38 | 6WLC | cryo_em | SARS-CoV-2 nucleocapsid | Crystal Structure of NSP15 Endoribonuclease from SARS CoV-2 in the Complex with Uridine-5'-Mono | X-RAY DIFFRACTION | 2.9→1.82 | **IDENT** | **MM** | **RM** | protein_only | ok | match |
| 39 | 7JTL | cryo_em | SARS-CoV-2 RBD-ACE2 | Structure of SARS-CoV-2 ORF8 accessory protein | X-RAY DIFFRACTION | 2.3→2.04 | **IDENT** | **MM** | **RM** | protein_only | ok | match |
| 40 | 7K3G | cryo_em | SARS-CoV-2 spike closed | SARS-CoV-2 Envelope Protein Transmembrane Domain: Pentameric Structure Determined by Solid-Stat | SOLID-STATE NMR | 2.6→None | **IDENT** | **MM** | **RM** | protein_only | ok | match |

Legend: IDENT = identity error; STATE = ligation-state error; MM = method mismatch;
RM = resolution mismatch (strict); rm01 = mismatch only under strict 0.005 Å rule
(1BPI: recorded 1.10 vs official 1.09); C3 values: `protein_only`,
`nucleic_acid_only` (INELIGIBLE for protein-only protocol),
`mixed_protein_nucleic_acid` (INELIGIBLE by default pending explicit criteria).

## Per-row adjudication rationale (C1)

- **1AKE** [match]: adenylate kinase = official title
- **1AON** [match]: GroEL/GroES complex = official title
- **1BPI** [match]: BPTI is the standard abbreviation of the official title
- **1BRS** [match]: barnase-barstar complex = official title
- **1D3Z** [match]: ubiquitin NMR = official title
- **1DDL** [identity_error]: recorded 'Dihydroorotase'; official structure is Desmodium yellow mottle tymovirus (virus particle, protein+RNA)
- **1EJG** [identity_error]: recorded 'Cholesterol oxidase'; official structure is crambin [AUDITOR-CORROBORATED]
- **1FIN** [match]: CDK2-cyclin A = cyclin A-CDK2 complex (same complex, component order swapped)
- **1GB1** [match]: protein G B1 = immunoglobulin-binding domain of protein G
- **1GCI** [identity_error]: recorded 'Glucose isomerase'; official structure is a serine protease (Bacillus lentus subtilisin) at 0.78 A
- **1GFL** [match]: GFP = green fluorescent protein
- **1HHO** [state_error]: recorded 'Deoxyhemoglobin'; official structure is human OXYhaemoglobin (ligation state contradicted)
- **1I0T** [identity_error]: recorded 'Ferredoxin'; official structure is Z-DNA hexamer CGCGCG (nucleic acid, not a protein) [AUDITOR-CORROBORATED]
- **1L2Y** [identity_error]: recorded 'Villin headpiece'; official structure is Trp-cage miniprotein TC5b
- **1MBO** [match]: 'Myoglobin' does not assert a state; official is oxymyoglobin (imprecision noted, resolution error counted in C2) — *imprecision note:* official structure is OXYmyoglobin; recorded 'Myoglobin' asserts no state
- **1NEK** [identity_error]: recorded 'Nek2 kinase'; official structure is E. coli Complex II / succinate dehydrogenase
- **1PPE** [identity_error]: recorded 'Porcine elastase'; official structure is bovine beta-trypsin + CMTI-I squash-seed inhibitor complex
- **1RVS** [identity_error]: recorded 'BPTI NMR'; official structure is transthyretin amyloid fibrils (solid-state MAS NMR)
- **1TEN** [match]: tenascin = fibronectin type III domain from tenascin
- **2ACE** [match]: acetylcholinesterase = official title (resolution error counted in C2)
- **2CBA** [match]: carbonic anhydrase = carbonic anhydrase II (resolution error counted in C2)
- **2HBS** [match]: sickle-cell hemoglobin = deoxyhemoglobin S (resolution error counted in C2)
- **2JOF** [match]: Trp-cage miniprotein = official title
- **2KOX** [identity_error]: recorded 'GB1 domain NMR'; official structure is ubiquitin (76-residue canonical sequence, entity description 'Ubiquitin')
- **2LYZ** [match]: hen lysozyme = hen egg-white lysozyme
- **2MJB** [identity_error]: recorded 'Amyloid beta NMR'; official structure is ubiquitin(-L40 fusion) solution NMR
- **2N0A** [match]: alpha-synuclein = official molecule; fibril state + solid-state NMR recorded as imprecision (method subclass error counted in C2) — *imprecision note:* official structure is fibrillar (solid-state NMR); recorded implies solution NMR by category
- **2OV0** [identity_error]: recorded 'Lysozyme ultra-high'; official structure is amicyanin (blue copper protein)
- **2VB1** [identity_error]: recorded 'Crambin ultra-high res'; official structure is hen egg-white lysozyme (HEWL) at 0.65 A [AUDITOR-CORROBORATED]
- **3J9I** [identity_error]: recorded '80S ribosome'; official structure is T. acidophilum 20S proteasome
- **3LZM** [match]: T4 lysozyme = official title
- **3NIR** [identity_error]: recorded 'Concanavalin A'; official structure is crambin at 0.48 A [AUDITOR-CORROBORATED]
- **3PGK** [match]: phosphoglycerate kinase = yeast PGK (resolution error counted in C2)
- **5A63** [identity_error]: recorded 'TRPV1 channel'; official structure is human gamma-secretase complex
- **5T4O** [identity_error]: recorded 'Spliceosome'; official structure is E. coli ATP synthase (autoinhibited, 6.9 A)
- **6J6J** [identity_error]: recorded 'Human 26S proteasome'; official structure is biotin-bound streptavidin
- **6NB6** [identity_error]: recorded 'ABC transporter'; official structure is SARS-CoV + human S230 antibody Fab complex
- **6WLC** [identity_error]: recorded 'SARS-CoV-2 nucleocapsid'; official structure is SARS-CoV-2 NSP15 endoribonuclease (X-ray, 1.82 A)
- **7JTL** [identity_error]: recorded 'SARS-CoV-2 RBD-ACE2'; official structure is SARS-CoV-2 ORF8 accessory protein (X-ray)
- **7K3G** [identity_error]: recorded 'SARS-CoV-2 spike closed'; official structure is SARS-CoV-2 envelope protein TMD pentamer (solid-state NMR)

## Per-row provenance (source revision + digests)

| PDB | RCSB revision (date) | API resp SHA-256 (entry) | Coord bytes (fresh=v24) | Coord SHA-256 (fresh=v24) |
|---|---|---|---|---|
| 1AKE | 2024-12-25 | `54d17f4eccc7c924…` | 357777 = 357777 | `651e952f55f1317f…` = `651e952f55f1317f…` |
| 1AON | 2024-05-22 | `01b5d00ac0422c3d…` | 4973076 = 4973076 | `5cddcf0ebe222238…` = `5cddcf0ebe222238…` |
| 1BPI | 2024-10-23 | `22ac73fb25dc0e40…` | 81324 = 81324 | `2289dd009b6eae05…` = `2289dd009b6eae05…` |
| 1BRS | 2024-02-07 | `ba1179fdfceb5c28…` | 466965 = 466965 | `0076aae54252706a…` = `0076aae54252706a…` |
| 1D3Z | 2024-05-22 | `b7cbea751162966d…` | 1015821 = 1015821 | `21099cb88231455f…` = `21099cb88231455f…` |
| 1DDL | 2024-04-03 | `30926f6f320e2ab7…` | 441369 = 441369 | `352e1d667bfabde8…` = `352e1d667bfabde8…` |
| 1EJG | 2024-10-30 | `82475838e58753b3…` | 124416 = 124416 | `115e25b3c80a72b5…` = `115e25b3c80a72b5…` |
| 1FIN | 2024-02-07 | `a71a8736d02ee0d2…` | 817776 = 817776 | `12f7920d265a08c0…` = `12f7920d265a08c0…` |
| 1GB1 | 2024-05-22 | `d0758798f9e8b4b7…` | 4197258 = 4197258 | `26ad823df283b7b0…` = `26ad823df283b7b0…` |
| 1GCI | 2024-05-22 | `73f957fa84f56fc2…` | 717660 = 717660 | `67155b6bd0085c6c…` = `67155b6bd0085c6c…` |
| 1GFL | 2024-10-23 | `273833bd2ee89bf6…` | 360126 = 360126 | `60eb370ad1a2c7c6…` = `60eb370ad1a2c7c6…` |
| 1HHO | 2026-08-12 | `75f8e5ebedd72328…` | 244296 = 244296 | `f2d60a04ac027f55…` = `f2d60a04ac027f55…` |
| 1I0T | 2024-02-07 | `62ae7c59e81ada35…` | 49572 = 49572 | `d1349a882000fc68…` = `d1349a882000fc68…` |
| 1L2Y | 2024-05-08 | `03aae84eaf542e34…` | 959202 = 959202 | `5d1bbb545a312dff…` = `5d1bbb545a312dff…` |
| 1MBO | 2026-08-12 | `c860a6b684579dd7…` | 160947 = 160947 | `d7e07c844714def8…` = `d7e07c844714def8…` |
| 1NEK | 2026-08-12 | `914721e829789202…` | 803439 = 803439 | `be379bd72d9d0148…` = `be379bd72d9d0148…` |
| 1PPE | 2024-10-23 | `6bd046f81d422234…` | 203958 = 203958 | `fe51b4280055199c…` = `fe51b4280055199c…` |
| 1RVS | 2024-05-01 | `1ef88b879a732bd7…` | 293382 = 293382 | `5203953c7022cfdf…` = `5203953c7022cfdf…` |
| 1TEN | 2024-02-14 | `69c598b0df8ee931…` | 114858 = 114858 | `5b2165e4e495d05e…` = `5b2165e4e495d05e…` |
| 2ACE | 2024-10-23 | `42ca8d6e5ce42a51…` | 400059 = 400059 | `572b0cdd389537d3…` = `572b0cdd389537d3…` |
| 2CBA | 2024-10-23 | `a98d1d1ca4c59fe3…` | 219510 = 219510 | `7862c050b41ed8a8…` = `7862c050b41ed8a8…` |
| 2HBS | 2026-08-12 | `c498b718f147aca3…` | 871803 = 871803 | `b552883a48cd11bf…` = `b552883a48cd11bf…` |
| 2JOF | 2024-05-08 | `a72e8c49d33464ca…` | 664443 = 664443 | `2cb2ebc097abed3c…` = `2cb2ebc097abed3c…` |
| 2KOX | 2024-05-01 | `ad3f5fca17e6ae79…` | 64008873 = 64008873 | `d7fadf57dbf9a91d…` = `d7fadf57dbf9a91d…` |
| 2LYZ | 2024-10-23 | `004d6a9c4d738b91…` | 133569 = 133569 | `722b8b6fb7d465ee…` = `722b8b6fb7d465ee…` |
| 2MJB | 2024-05-15 | `ac687c75a0609018…` | 2013255 = 2013255 | `547b49a69c29b3f7…` = `547b49a69c29b3f7…` |
| 2N0A | 2024-05-15 | `708c04fc41ecd288…` | 1665927 = 1665927 | `cc2aaebd34924b82…` = `cc2aaebd34924b82…` |
| 2OV0 | 2023-08-30 | `e39addbfcac4bd5a…` | 196668 = 196668 | `3eafc180aa32668e…` = `3eafc180aa32668e…` |
| 2VB1 | 2024-11-13 | `761eac098d3a3c52…` | 447444 = 447444 | `cb971a808effff36…` = `cb971a808effff36…` |
| 3J9I | 2024-02-21 | `12eb17ab2197dac9…` | 3865968 = 3865968 | `f87dc96adccaaaef…` = `f87dc96adccaaaef…` |
| 3LZM | 2024-05-22 | `25ba0755e4e345e0…` | 153495 = 153495 | `e531a3c16462ebdc…` = `e531a3c16462ebdc…` |
| 3NIR | 2024-11-20 | `e943b7cc1ebde6fe…` | 163701 = 163701 | `b1ecd8b00fe1b0e2…` = `b1ecd8b00fe1b0e2…` |
| 3PGK | 2024-11-20 | `95dfa8efa5b9098b…` | 294759 = 294759 | `32abf08811f5a2e0…` = `32abf08811f5a2e0…` |
| 5A63 | 2024-11-13 | `26f83ded94c89ddf…` | 915300 = 915300 | `cc9adb1be03dc8cc…` = `cc9adb1be03dc8cc…` |
| 5T4O | 2024-03-13 | `20ef7a2b5cbba2f7…` | 2337093 = 2337093 | `cec2efd1f123740b…` = `cec2efd1f123740b…` |
| 6J6J | 2025-07-02 | `8e3f275505e28fb3…` | 323433 = 323433 | `e699b9911536491a…` = `e699b9911536491a…` |
| 6NB6 | 2024-11-20 | `c325f199e69cf5ff…` | 2539917 = 2539917 | `991c1be973ae74f8…` = `991c1be973ae74f8…` |
| 6WLC | 2023-10-18 | `ceec014a275deaee…` | 1055430 = 1055430 | `b2d6d15fcdbd8fa4…` = `b2d6d15fcdbd8fa4…` |
| 7JTL | 2024-10-09 | `61b9c535d407f00d…` | 330237 = 330237 | `9d0bd8d6d5c7d82d…` = `9d0bd8d6d5c7d82d…` |
| 7K3G | 2024-05-15 | `0aba23df2e370ef3…` | 2087370 = 2087370 | `2982f5a386ec27c0…` = `2982f5a386ec27c0…` |

Full 64-hex digests, raw API responses, entity descriptions, deposited dates, parse
anomaly details (multi-model counts, altloc characters, insertion codes) are in
`n7_od16_40target_table.json` and `rcsb-api/`. Exemplar coordinate files for the four
auditor-corroborated cases (1EJG, 3NIR, 1I0T, 2VB1) are in `coordinates-exemplars/`.
