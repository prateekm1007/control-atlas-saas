# Count Reconciliation — All Claims, Row-Derived (Round 10, supersedes `20-40_vs_23-40_RECONCILIATION.md`)

**Scope.** Auditor direction T5 (Round 10), continuing direction 4 (Round 9).
Several different "X/40" figures have circulated. They are **different
metrics with different rules**; they are never merged into one "mismatch
rate." Every headline count below is derived from the 40-row item-level
table (`n7_od16_40target_table.json` / `.md`), which is itself derived from
fresh, bundled raw evidence (RCSB API responses + coordinate downloads).

**Why this file replaces its predecessor.** The prior document
(`20-40_vs_23-40_RECONCILIATION.md`, preserved unchanged inside the original
r1 archive) attempted to explain the transcript's "20/40" as a
description-mismatch count under a narrower rule. The auditor has now
corrected the provenance of that figure (T5): **"at most 20 of 40
experimental structures could pass" was the auditor's own earlier bound,
derived without recomputing.** It was never a coder-measured
description-mismatch count, and the r1 document's §2 explanation
(boundary-row exclusion) is retracted as an explanation of "20" — it
remains valid only as the explanation of the 21-vs-22 identity-rule
boundary below.

## 1. The corrected record for "20 of 40" (auditor T5)

- **Origin of the figure.** The auditor's earlier statement: "at most 20 of
  40 experimental structures could pass" — a bound derived **without
  recomputation** (auditor's own correction, Round 10).
- **The tracked artifact.**
  `docs/audit-evidence/2026-10-19/science-validity/independent_recompute_20_of_40.json`
  (blob `6cda70e2791d50325643e8fbbf56db7ee9948f8d`, branch
  `science/p0-correctness-2026-10-19` @ `ebc1fd7`, generated
  2026-10-18T20:50:27Z) tested exactly that claim by applying the current
  modality matrix (PIL-CAL-03) to the recorded v23 per-law rows:
  - `could_pass: 0` of 40 (the auditor's "≤ 20" bound was therefore true
    but loose; the artifact's conclusion — the bound is not reproducible as
    an equality — stands);
  - **38** of 40 blocked by **LAW-120 at 10°**;
  - **2** of 40 blocked by **LAW-170**: **1I0T and 1DDL**;
  - recorded verdict histogram (all 50 targets of the recorded run):
    VETO 44, INDETERMINATE 5, PASS 1.
- **Historical label (mandatory).** Both figures — the auditor's bound and
  the artifact's 0/40 — describe the **recorded v23 run**, not a post-fix
  run, and not any future run. All v23-derived values are **historical**.
- **Replacement rule.** Wherever "20 of 40" (or "20/40") was previously
  presented as a pass-eligibility figure, the corrected statement is:
  *"0 of 40 experimental structures could pass under the recorded v23 rows
  and the current modality matrix (38 blocked by LAW-120 at 10°, 2 by
  LAW-170: 1I0T, 1DDL); historical, recorded-v23-run figures."* Citations
  must name the artifact above.

## 2. The five independently counted columns (fresh, row-derived)

| Metric (column) | Definition (documented) | Fresh count (this bundle) |
|---|---|---|
| A. Incorrect descriptive metadata | recorded `desc` names a different molecular system (identity) or asserts a contradicted ligation/assembly state | **22/40** (21 identity + 1 state) |
| B. Incorrect method | category-implied method vs official RCSB EXPDTA | **5/40** |
| C. Incorrect resolution | recorded vs official `resolution_combined[0]` | **24/40** strict (\|Δ\|>0.005 Å); **23/40** at 0.01 Å tolerance |
| D. Polymer/entity identity & cohort eligibility | entity class of the actual acquired structure vs a protein-only protocol | **2/40** flagged (1I0T nucleic-acid-only; 1DDL protein+RNA virus) |
| E. Coordinate-byte mismatch vs v24 manifest | fresh SHA-256 vs `runs/v24/coordinate_manifest.json` | **0/40** |
| Parse failures (C4) | PDB record-level parse failures this session | **0/40** |

Combined method-or-resolution (B∪C): 26/40 strict, 25/40 tolerant. Rows with
≥1 defect across A∪B∪C∪D: **32/40**. Fully clean: **8/40** (1AKE, 1AON,
1D3Z, 1GB1, 1GFL, 2JOF, 2LYZ, 3LZM).

**These columns are never summed into a single "mismatch" number.** A
structure can be byte-perfect (E=match) and parse cleanly while carrying a
false description (A) and a wrong resolution (C) — e.g., 3NIR: bytes match
v24 exactly, parses cleanly, but the recorded "Concanavalin A at 1.00 Å" is
actually crambin at 0.48 Å.

## 3. Reconciling the transcript's "22/40" identity/state count

The fresh count under the documented rule is **22/40** (21 identity + 1
state), matching the transcript's reported split exactly. The single
boundary row between 21 and 22:

1. **1HHO** — recorded "Deoxyhemoglobin"; the official structure is human
   *oxy*haemoglobin. Classified as a `state_error` (the recorded string
   asserts a specific, contradicted ligation state). A rule counting only
   *different-molecule* errors (pure identity) would exclude it: 22−1 = 21.
2. **2KOX** — recorded "GB1 domain NMR"; the official entity is ubiquitin.
   Classified as an `identity_error` under any rule that inspects entity
   identity (the entry title also names ubiquitin, not GB1); only a rule
   that never inspects entity identity would miss it.

(The r1 document additionally offered these rows as an explanation of the
transcript's "20/40"; that use is **retracted** per §1 — the 20-figure is
the auditor's un-recomputed pass bound, now corrected to 0/40 by the
tracked artifact.)

## 4. Reconciling the transcript's "23/40" resolution count

- REMARK 2 / API resolution vs recorded resolution: **24/40** strict
  (\|Δ\|>0.005 Å), **23/40** at 0.01 Å tolerance. The one strict-only row
  is 1BPI (recorded 1.10 vs official 1.09 — a rounding-level difference).
- The transcript's "23/40 resolution discrepancies under a 0.01 Å tolerance"
  matches the tolerant count exactly.
- Strict and tolerant comparisons are always reported **independently**
  (auditor direction 4). The floating-point comparison uses an explicit
  epsilon (`> 0.01 + 1e-9`) so that recorded 1.10 vs official 1.09 is
  treated as rounding-level, not as a strictly-greater-than-0.01 difference
  (a naive float comparison of `1.1 - 1.09 > 0.01` evaluates true due to
  representation error and would silently turn the tolerant count into 24).

## 5. Why the pass-eligibility metric and the defect metrics are incommensurable

- The **pass-eligibility** figure (now 0/40, historical, recorded-v23-run)
  is an *outcome* metric: it applies law thresholds and the modality matrix
  to recorded measurement rows.
- The **defect counts** (22/40, 5/40, 24/40, 23/40, 2/40, 32/40, 8 clean)
  are *input-metadata* metrics: they compare the cohort's recorded labels
  against authoritative RCSB records. They say nothing about verdicts.
- The two can move independently: a perfectly labeled cohort could still
  have 0/40 pass under strict laws; a defect-riddled cohort can still
  produce verdicts (the recorded v23 run produced VETO 44 / INDETERMINATE
  5 / PASS 1 — historical). Conflating them hides both facts.

## 6. What the byte-match column does and does not establish

**0/40 coordinate-byte mismatches vs the v24 manifest** establishes: the
coordinate files downloaded from `files.rcsb.org` are byte-identical to the
ones the v24 run recorded on 2026-10-18, and the v24 acquisition was
byte-stable for these entries. It establishes **nothing** about cohort
appropriateness: 32/40 rows carry at least one metadata defect, 2/40
acquired structures are not protein-only, and the recorded descriptions
identify the wrong molecule in 21/40 cases. Matching historical bytes for
mislabeled inputs yields a mislabeled cohort. The auditor's instruction —
never treat byte-match as scientific appropriateness — is the operative
conclusion, now also encoded in OD-17.

## 7. Method note

All fresh counts derive from `n7_od16_40target_table.json` (40 rows) via
`09-scripts/adjudicate_table.py`; classification rules and per-row
rationales are embedded in that JSON and rendered in
`n7_od16_40target_table.md`. Raw RCSB API responses and per-row digests are
bundled (`rcsb-api/`). The clean-checkout reproduction
(`reproduce-clean-checkout.sh`, log bundled) re-derived all totals
identically (22/5/24/23/1/1/0/0/32) from a fresh clone + fresh RCSB
fetches. No calibration, threshold derivation, verdict issuance, cohort
change, or golden-artifact regeneration was performed (hard stop).
