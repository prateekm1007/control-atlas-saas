# Constitution Reading Note — Session 2 (Round 9 continuation), 2026-10-20

**Read by:** coder agent, in-session. This note is the current-session reading
evidence required by auditor direction 1 of the Round-9 continuation
("Re-fetch, verify and read both pinned documents in full. Preserve the
current-session reading note, exact blob SHAs, count conventions, commands,
timestamps and edited-file inventory. Do not rely on the transcript alone as
proof of compliance."). It does not rely on the prior session's reading note
(`READING_NOTE.md`, preserved unchanged alongside this file) for the fact or
content of the reading.

**Session UTC window:** 2026-10-19T20:44Z – 2026-10-19T21:0xZ (sandbox UTC
clock; user-local date 2026-10-20). Exact command timestamps are recorded
below where captured.

**Edited-file inventory for this session (all documentation/evidence, no
repository writes):** this note; `04-decisions/OWNER_DECISIONS.md` (rev 3);
`02-n7-od16-cohort-audit/COUNT_RECONCILIATION_ALL_CLAIMS.md` (new; replaces
`20-40_vs_23-40_RECONCILIATION.md`); `02-n7-od16-cohort-audit/
N7_OD16_DISCREPANCY_REPORT.md` (§6 corrected); `05-n3-gate-reconciliation/
WORD_TARGET_OD-21_UNCONFIRMED.md` (new) and `N3_COUNT_CORRECTION_v2.md` (§5
superseded); `08-lost-work-statement/LOST_WORK_REGISTER.md` (not-pushed record
added); `README.md` (rev 2); `verifier.sh` (locale pin + word counts);
`r2-CHANGELOG.md` (new); `MANIFEST.sha256` (regenerated). No file inside the
read-only clone was modified; no push, merge, deployment, calibration,
held-out evaluation, threshold change, cohort change, or golden-artifact
regeneration was performed.

## 0. Sequence evidence (auditor task T9): fetch → read → first edit

| Event | UTC timestamp | Evidence |
|---|---|---|
| Fresh `git fetch --all --prune` on the read-only clone | 2026-10-19T20:47Z | command output in §2 (exit 0; no ref movement — confirms no branch moved and no new remote branch appeared) |
| Pinned-blob re-verification after fetch | 2026-10-19T20:47Z | §2 `git ls-tree` outputs (all four MATCH) |
| Byte copies of both constitutions dumped and hash-verified | 2026-10-19T20:48:56Z | §2 `git hash-object` outputs |
| Both documents read end-to-end (Read of the dumped copies) | 2026-10-19T20:48–20:49Z | between the dump and the counting run below |
| Counting-convention derivation (incl. whitespace word counts) | 2026-10-19T20:49:19Z | script output in §2 |
| **First edit of this session** (this reading note first written) | **2026-10-19T20:51:00Z** | filesystem mtime captured via `stat` before any later edit: `READING_NOTE_session2_2026-10-20.md: mtime 2026-10-19 20:51:00.395777309 +0000` |

The read (20:48–20:49Z) precedes the first edit (20:51:00Z). The staging
copy of the r1 bundle (`cp -a` into the r2 build directory, 20:50:51Z per
directory mtime) is a byte-preserving copy, not a content edit; the first
content written into it was this reading note. All Round-10 (T-task) edits
occur after 20:51:00Z and therefore after the read.

## 1. Documents read, in full, this session

| Document | Source | Git blob SHA-1 (verified this session) | Bytes | Chars | LF | split() elements | Nonblank lines |
|---|---|---|---|---|---|---|---|
| Domain Constitution `constitution.md` (v6.1-Hardened) | `origin/main` @ `2195a048e87dcec4aa63e8dc7981b3bb6d237ca0`, read-only clone re-fetched this session | `211ad2c5d4b40059d9f3f03de12e0701f9235bc7` | 622 | 615 | 11 | 12 | 9 |
| Engineering Constitution `ENGINEERING_CONSTITUTION.md` (v1.0.0, Proposed) | `origin/policy/engineering-constitution` @ `4993cb3b6954ffb8ecad281817b2c59f1f8fc041` | `b6bb35e84956d84a8c9d9e65734c212baf3ed075` | 20,572 | 20,564 | 178 | 179 | 129 |

Both documents were read end-to-end in this session: the domain constitution
in full (both ACTIVE rules, OBS-153 and CRIT-154), and the engineering
constitution in full (all 15 numbered sections plus the final rule). Reading
was performed on exact byte copies dumped from the re-fetched read-only clone
(hash-verified before reading; commands in §2).

## 2. Verification commands and outputs (this session, in order)

```
# 0. environment ground truth (sandbox persisted from the Round-9 session;
#    archive under delivery was present and byte-verified first):
$ stat -c '%s bytes' control-atlas-evidence-2026-10-20-round9.tar.gz
  22560251 bytes
$ sha256sum control-atlas-evidence-2026-10-20-round9.tar.gz
  42d8e8819bc7024bfad1d9a511c7707046c3c2a0b3ff38a07fc49d4861297528
$ tar -tzf control-atlas-evidence-2026-10-20-round9.tar.gz | wc -l
  182

# 1. fresh read-only fetch (no credentials; no push possible or attempted),
#    2026-10-19T20:47Z:
$ git fetch --all --prune     # exit 0; no ref changes reported

# 2. pinned-blob re-verification AFTER the fetch (2026-10-19T20:47Z):
$ git ls-tree origin/main -- constitution.md
  100644 blob 211ad2c5d4b40059d9f3f03de12e0701f9235bc7  constitution.md
$ git ls-tree origin/policy/engineering-constitution -- ENGINEERING_CONSTITUTION.md
  100644 blob b6bb35e84956d84a8c9d9e65734c212baf3ed075  ENGINEERING_CONSTITUTION.md
$ git ls-tree origin/science/p0-correctness-2026-10-19 -- backend/calibration/dataset_v23.py
  100644 blob 3a5358374b2037b9475bd2d494754944485da5ac  backend/calibration/dataset_v23.py
$ git ls-tree origin/science/p0-correctness-2026-10-19 -- docs/P0_STATUS.md
  100644 blob 22ca8ce9c0c79ba396e8a4569f419d9fa6f01d0a  docs/P0_STATUS.md
$ git rev-parse origin/main origin/science/p0-correctness-2026-10-19
  2195a048e87dcec4aa63e8dc7981b3bb6d237ca0
  ebc1fd79f20b9a6b6a262a70ce6942ba069d19e9

# 3. exact byte copies dumped from the git objects, then hash-verified,
#    2026-10-19T20:48:56Z:
$ git show origin/main:constitution.md > constitution.domain.md
$ git show origin/policy/engineering-constitution:ENGINEERING_CONSTITUTION.md \
    > ENGINEERING_CONSTITUTION.md
$ git hash-object constitution.domain.md ENGINEERING_CONSTITUTION.md
  211ad2c5d4b40059d9f3f03de12e0701f9235bc7
  b6bb35e84956d84a8c9d9e65734c212baf3ed075

# 4. counting-convention re-derivation (persisted script
#    09-scripts/session2_constitution_counts.py, run 2026-10-19T20:49:19Z):
  constitution.domain.md:  bytes=622   chars=615   LF=11  split=12  nonblank=9
  ENGINEERING_CONSTITUTION.md: bytes=20572 chars=20564 LF=178 split=179 nonblank=129
  (both computed blob SHA-1 values MATCH the pinned blobs)
```

All four pinned blob identities match the remote **after** the fresh fetch
(no drift). Both counting conventions match the previously reconciled
conventions byte-exactly.

### 2a. The single counting convention (auditor task T1)

Per the Round-10 direction (T1), one convention governs every count in this
bundle, pinned in the verifier (`LC_ALL=C.UTF-8`, `LANG=C.UTF-8`):

| Quantity | Rule | Domain | Engineering |
|---|---|---|---|
| Bytes | `len(data)` (octets) | 622 | 20,572 |
| Characters | `len(text)` after UTF-8 decode | 615 | 20,564 |
| Words | `len(text.split())` — whitespace split; shell: `wc -w` under `LC_ALL=C.UTF-8` | **84** | **2,784** |
| Lines (LF) | `text.count('\n')` | 11 | 178 |
| split(`'\n'`) elements | `len(text.split('\n'))` | 12 | 179 |
| Non-blank lines | lines with `.strip()` truthy | 9 | 129 |

**Convention labels are mandatory wherever a number appears.** The figures
11/12/9 and 178/179/129 are **line counts (LF / split-elements / non-blank
lines), not word counts**; the word counts are 84 and 2,784 (verified this
session: `LC_ALL=C.UTF-8 wc -w -m -c` → `84 615 622` and `2784 20564 20572`,
matching the auditor's figures). Earlier documents that called 11/12/9 and
178/179/129 "word counts" are corrected in this revision (see
`r2-CHANGELOG.md`); no count that cannot be reproduced under this pinned
convention remains in the bundle. Git blob SHA-1 =
`sha1(b"blob %d\0" % len(data) + data)`, cross-checked with `git hash-object`.

## 3. Invariant IDs in force this round (auditor requirement: cite every EC, OBS, and CRIT ID enforced)

**Domain Constitution (v6.1-Hardened) — both IDs are ACTIVE and in force:**

- **OBS-153 — Avidity Quantification**: bipodal success measured by Contact
  Density ρ; success requires ρ(Bipod) ≥ 2.5 × ρ(Monopod); ρ = count
  of unique heavy-atom contacts within 4.5 Å. *Status this round:* in force;
  not exercised (no measurement, calibration, or design work performed —
  hard stop; documentation and evidence only).
- **CRIT-154 — Structural Admissibility**: Two-Stage Warhead-RMSD < 1.0 Å
  against clinical benchmarks (PDB: 5NIU); veto on non-physical target
  deformation (steric clash < 1.2 Å). *Status this round:* in force; not
  exercised (same reason).

**Engineering Constitution (v1.0.0, Proposed) — all fifteen numbered sections
plus the Final Rule were read in full this session (§1 Purpose and authority;
§2 Mandatory pre-coding protocol; §3 Security is a release requirement; §4
Product and scientific integrity; §5 Architecture and maintainability; §6
Testing and evidence; §7 CI/CD and supply chain; §8 Reliability/
observability/operations; §9 Customer experience/accessibility/cost control;
§10 LLM and external-provider boundaries; §11 Change/release/incident
discipline; §12 Definition of done; §13 Prohibited shortcuts; §14 Required
task artifacts; §15 External references; Final rule). The sections
**enforced by this round's work** are:

- **EC §1** (authority; conflict rule): conflicting counts (20/40 vs 22/40
  vs 23/40; 5,460 vs 5,470) are recorded and reconciled, never silently
  resolved by editing whichever source is easiest (T4/T5 executions).
- **EC §2** (pre-coding protocol): this note, with repository/branch/base
  state and blob identities, exists before any further edits (§0 sequence
  evidence: read precedes first edit).
- **EC §4** (product and scientific integrity): every count is MEASURED,
  AUDITOR_ATTESTED, or CODER_REPORTED; non-success states are never
  converted into favorable ones; byte-matching inputs are not represented
  as cohort-label validity (OD-17 record).
- **EC §6** (testing and evidence): claimed results carry exact commands,
  identities, and counts; no invented counts; the distinct metrics are kept
  distinct (T1/T5).
- **EC §11** (change and incident discipline): OD-15 (incident) remains
  OPEN; no history rewritten as a substitute for response (T7 record).
- **EC §13** (prohibited shortcuts): no unevidenced claims; lost work stays
  LOST; no gate weakening; no error-to-verdict conversions; no number chosen
  for the unconfirmed word target (T4).
- **EC §14** (required task artifacts): this bundle (reading note, register,
  reconciliations, changed-file manifest, patch/bundle provenance) is the
  task-artifact set for this documentation-only change.
- **Final rule**: evidence preserved before any authority change; the
  original r1 archive remains delivered byte-identical alongside this
  revision; historical dataset_v23.py and calibration outputs untouched.

EC §3, §5, §7–§10, §12 are in force but not exercised this round: no code,
security, CI, or release work was performed (documentation and evidence
only, under the hard stop).

## 4. Distinction between reading and gate passage (per the auditor)

The auditor directed that the distinction between *reading* the documents and
*passing the technical gates they require* be preserved. This session has
performed the reading and the identity/count verification only. The technical
gates the Engineering Constitution requires for code changes (preflight
artifacts, regression evidence, CI on merge candidates, owner review) are NOT
exercised or claimed here: this session produced documentation and evidence
only, under the active hard stop (PR #16 open/unmerged, verified in the
Round-9 session and re-confirmed unchanged by the no-op fetch above — no ref
movement on any audited branch).
