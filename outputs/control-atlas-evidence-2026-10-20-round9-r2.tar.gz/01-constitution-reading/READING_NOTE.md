# Constitution Reading Note — Session of 2026-10-19/20 (Round 9)

**Read by:** coder agent, in-session (this document is the current-session reading
evidence required by auditor direction 1; it does NOT rely on any prior session's
reading notes).

**Session UTC window:** 2026-10-19T19:48Z – 2026-10-19T20:30Z (approximately;
exact command timestamps recorded below where captured).

## 1. Documents read, in full, this session

| Document | Source (read-only clone) | Git blob SHA-1 (verified) | Bytes | Chars | LF | split() elements | Nonblank lines |
|---|---|---|---|---|---|---|---|
| Domain Constitution `constitution.md` | `origin/main` of `github.com/prateekm1007/control-atlas-saas` | `211ad2c5d4b40059d9f3f03de12e0701f9235bc7` | 622 | 615 | 11 | 12 | 9 |
| Engineering Constitution `ENGINEERING_CONSTITUTION.md` (v1.0.0, Proposed) | `origin/policy/engineering-constitution` (commit `4993cb3b6954ffb8ecad281817b2c59f1f8fc041`) | `b6bb35e84956d84a8c9d9e65734c212baf3ed075` | 20,572 | 20,564 | 178 | 179 | 129 |

Both documents were read end-to-end in this session (the domain constitution in
full; the engineering constitution all 178 lines / 15 numbered sections plus the
final rule). Exact byte copies are bundled alongside this note as
`constitution.domain.md` and `ENGINEERING_CONSTITUTION.md`.

## 2. Verification commands and outputs (this session)

Repository cloned read-only (no push credentials available or used):

```
$ git clone https://github.com/prateekm1007/control-atlas-saas.git
  (completed 2026-10-19T19:57Z; origin/HEAD -> origin/main @ 2195a048)

$ git rev-parse origin/main:constitution.md
  211ad2c5d4b40059d9f3f03de12e0701f9235bc7

$ git rev-parse origin/policy/engineering-constitution:ENGINEERING_CONSTITUTION.md
  b6bb35e84956d84a8c9d9e65734c212baf3ed075

$ git rev-parse origin/science/p0-correctness-2026-10-19:backend/calibration/dataset_v23.py
  3a5358374b2037b9475bd2d494754944485da5ac

$ git rev-parse origin/science/p0-correctness-2026-10-19:docs/P0_STATUS.md
  22ca8ce9c0c79ba396e8a4569f419d9fa6f01d0a

$ git hash-object constitution.md          # working-tree copy, main checkout
  211ad2c5d4b40059d9f3f03de12e0701f9235bc7

$ python3 (counting script, see 09-scripts/ and §4)
  domain:    bytes=622  chars=615  LF=11  split=12  nonblank=9
  engineering: bytes=20572 chars=20564 LF=178 split=179 nonblank=129
```

All four pinned blob identities match the remote. All counting conventions
match the previously verified conventions exactly (no drift).

## 3. Enforced invariants identified (extraction of the operative rules)

### Domain Constitution (v6.1-Hardened)

- **OBS-153 — Avidity Quantification** (ACTIVE): bipodal success measured by
  Contact Density ρ; success requires ρ(Bipod) ≥ 2.5 × ρ(Monopod), where ρ is
  the total count of unique heavy-atom contacts within 4.5 Å.
- **CRIT-154 — Structural Admissibility** (ACTIVE): lead validation requires
  Two-Stage Warhead-RMSD < 1.0 Å against clinical benchmarks (PDB: 5NIU);
  veto on any design relying on non-physical target deformation (steric
  clash < 1.2 Å).

### Engineering Constitution (v1.0.0, Proposed) — section-level MUSTs

- **§2 Mandatory pre-coding protocol:** confirm repo/branch/tree/base SHA; read
  both constitutions in full and record paths/hashes; read current
  implementation, contracts, tests, deployment config; map change across trust
  boundaries; record preflight artifact; stop and report on conflicts that
  could change security posture, customer-visible results, or scientific
  meaning. A preflight attestation is not proof of understanding; automated
  checks enforce the invariants.
- **§3 Security is a release requirement:** fail closed; deny by default;
  authorize objects not just requests (tenant scoping, cross-tenant denial
  tests); secrets management (history-compromised until issuer confirms
  revocation); input validation at boundaries; callback/state protection;
  sensitive-data handling; ASVS-mapped evidence without compliance claims.
- **§4 Product and scientific integrity:** every authoritative result carries
  provenance (input digest, engine/version, law-registry hash, config, run
  status); non-success states are explicit and never converted into PASS/VETO/
  zero-valued measurements; synthetic data is test-only; `not measured` is
  distinct from `measured and passed/failed` and `measurement failed`;
  deterministic checks vs heuristics vs ML estimates vs user claims are
  distinguished; pre/post-refinement measurements stored separately; the law
  registry declares full metadata, and only tested executable entries marked
  enforced may be called enforced; law IDs are never silently renumbered.
- **§5 Architecture and maintainability:** defined component contracts; no
  duplicate sources of truth; dependency/import inspection before deletion or
  relocation; API schemas as versioned contracts; centralized validated
  configuration; justified pinned dependencies; tested migrations with
  rollback; smallest complete change.
- **§6 Testing and evidence:** failing regression test before fixing where
  feasible; coverage of unit/integration/contract/authz/invalid-input/concurrency/
  dependency-failure/production-error paths; deterministic isolated CI tests
  with controlled doubles; no weakening/skipping tests for green CI; claimed
  test results must include exact command, commit SHA, versions, counts —
  never invent counts.
- **§7 CI/CD and supply chain:** feature-branch + PR development; required
  checks on the exact merge candidate; deployment gated on the same SHA;
  CI includes security/dependency/container/law-registry drift checks;
  SLSA practices incrementally, no unverified level claims; pinned CI actions;
  releases have health checks and rollback.
- **§8 Reliability/observability/operations:** SLIs/SLOs measured before
  reliability claims; bounded timeouts, retries, idempotency; distinct
  health/readiness/business-success signals; structured logs without secrets;
  transactional persistence of authoritative results; alerts + runbooks;
  tested recovery exercises.
- **§9 Customer experience/accessibility/cost control:** honest errors, never
  fabricated results; accessibility as product quality; abuse controls on
  costly endpoints; core journey prioritized over half-tested integrations.
- **§10 LLM and external-provider boundaries:** narrative is advisory;
  authoritative verdicts survive model unavailability; external content is
  untrusted input; minimum-data transmission; provider unavailability produces
  honest degraded states.
- **§11 Change/release/incident discipline:** problem statement, acceptance
  criteria, risk assessment, tests, docs, rollback per impact; high-risk
  surfaces (security, thresholds, law meanings, schemas, billing) need focused
  regression evidence; incidents: containment, evidence preservation,
  root-cause, remediation, regression prevention.
- **§12 Definition of done:** includes exact base/proposed SHAs; regression +
  negative-path + contract tests; all required checks pass with saved evidence;
  docs/registry/runbooks updated; final report lists changes, evidence,
  unresolved risks, blocked checks, unverified items — "not run" is never
  "passed"; P0 vulnerabilities, cross-tenant exposure, fabricated verdicts,
  data corruption, failed gates, or undocumented scientific-semantic changes
  block release.
- **§13 Prohibited shortcuts:** no coding before the protocol; no unevidenced
  claims (testing, rotation, branch protection, deployment); no gate weakening;
  no secrets in artifacts; no implicit open auth; no mock data as production
  evidence; no error→verdict conversions; no law/threshold changes without
  decision + regression evidence; no deletion before dependency analysis; no
  merging unverified commits; no "complete" claims with unrun checks.
- **§14 Required task artifacts:** preflight + baseline SHA; scope/dependency
  map; machine-readable test results bound to the commit; changed-file
  manifest + patch hash; impact notes; migration/rollback plans; completed/
  blocked/unverified checklist; repeatable-command generation, redacted.
- **§15 External references:** SSDF SP 800-218, OWASP ASVS 5.0.0, SLSA v1.2 —
  as mapping references, not compliance claims.
- **Final rule:** build trust before features; prove behavior before claiming
  success; preserve evidence before changing authority; automate every
  checkable invariant.

## 4. Counting method (reproducible)

`len(data)` for bytes; `len(text)` for characters (UTF-8 decode);
`text.count('\n')` for LF; `len(text.split('\n'))` for split elements;
nonblank = lines with `.strip()` truthy. Git blob SHA-1 computed as
`sha1(b"blob %d\0" % len(data) + data)` and cross-checked with
`git hash-object` / `git rev-parse`.

## 5. Observations binding this session's work

1. §4 and §6 directly govern this session's deliverables: the OD-16
   discrepancy table must distinguish measured vs not-measured, and every
   count must derive from saved rows with exact commands — no invented counts.
2. §2 requires this reading note to exist before further edits; it is written
   before any document generation.
3. §13 forbids reconstructing lost evidence as if it were original history;
   the lost N8 series and prior archive are therefore declared LOST, never
   re-fabricated (see 08-lost-work-statement/).
4. The hard stop recorded on PR #16 (verified open/unmerged this session) is
   respected: no push, merge, deployment, calibration, held-out evaluation,
   threshold change, cohort change, or golden-artifact regeneration was
   performed in this session. All RCSB fetches were read-only metadata/
   coordinate acquisitions for the diagnostic table, as directed.
