# Control-Atlas Evidence Bundle — Round 9, Revision 2 (2026-10-20)

**Archive file:** `control-atlas-evidence-2026-10-20-round9-r2.tar.gz`
**Supersedes (and preserves):** `control-atlas-evidence-2026-10-20-round9.tar.gz`
(the r1 archive, 22,560,251 bytes, SHA-256 `42d8e8819bc7024bfad1d9a511c7707046c3c2a0b3ff38a07fc49d4861297528`)
— r1 remains delivered byte-identical alongside this revision; nothing is
silently replaced. Both supersede the unrecoverable prior-session archive
(`b2d43f7…`, see `08-lost-work-statement/`, item L-3).

**What r2 changes:** the Round-10 auditor directions T1–T10. Full mapping in
`r2-CHANGELOG.md`. Highlights: the single pinned counting convention
(bytes/UTF-8 chars/whitespace words, locale `C.UTF-8`); the corrected
"20 of 40" record (0 of 40 per the tracked artifact; v23 values labelled
historical); the OD-01…OD-21 decision register with OD-17…OD-21 recorded
OPEN (directives, not decisions); the word-target resolution (OD-21,
UNCONFIRMED, no number chosen); the not-pushed record (`94b0f7c`, `e9985c6`)
and A-06 legacy-branch record.

## Contents

| Path | Content | Provenance |
|---|---|---|
| `01-constitution-reading/` | Session-2 reading note (2026-10-20, this revision round: fetch→read→first-edit sequence evidence, EC/OBS/CRIT IDs, single counting convention) + the r1 session reading note + exact byte copies of both Constitutions | Read from a read-only clone, re-fetched this session; all pinned blob SHAs verified after fetch; conventions byte-exact (622/615/words 84/lines 11-12-9 and 20572/20564/words 2784/lines 178-179-129) |
| `02-n7-od16-cohort-audit/` | OD-17 (fka OD-16) discrepancy report (§6 corrected); item-level 40-target table (MD + JSON + raw RCSB API responses + 4 exemplar coordinates); **`COUNT_RECONCILIATION_ALL_CLAIMS.md`** (supersedes the r1 `20-40_vs_23-40_RECONCILIATION.md`); corrected-cohort proposal v2 | Fresh measurements (2026-10-19T20:01–20:07Z); scripts in `09-scripts/` |
| `03-n7-comparison/` | N7 paired comparison preserved with narrowed conclusion | Transcript figures kept `CODER_REPORTED`; no re-measurement (hard stop) |
| `04-decisions/` | **`OWNER_DECISIONS.md` rev 3** — the OD-01…OD-16 register (auditor's, unchanged, fragments as stated) + **OD-17…OD-21 all OPEN** (directives, decided-by blank, none implemented) + D-xx internal-label crosswalk + owner actions A-01…A-06 + not-pushed record + closure protocol (T10) | Auditor adjudications recorded; no owner approval asserted |
| `05-n3-gate-reconciliation/` | N3 count-correction v2 (§5 superseded in place) + **`WORD_TARGET_OD-21_UNCONFIRMED.md`** | Counts re-derived from the remote-pinned `P0_STATUS.md` blob; word target unconfirmed (no tracked record of 5,460 or 5,470 — auditor- and coder-verified) |
| `06-git-bundles/` | 6 verified git bundles (main, science/p0-correctness, science/law-validity-wp15 = PR-16 head, chore/hygiene, policy/engineering-constitution, integration/p0-hardening) with pinned tips | Generated from the read-only clone; `git bundle verify` passes on all |
| `07-patch-series/` | 33 format-patch files (28 + 2 + 2 + 1) + `SERIES_PROVENANCE.md` | All patches correspond to commits inside the verified bundles; nothing reconstructed |
| `08-lost-work-statement/` | Lost-work register, now with the Round-10 not-pushed record (docs branch `94b0f7c`; N8 branch `e9985c6`) | Honest statement of what is `NOT_REPRODUCIBLE`; no-reconstruction policy |
| `09-scripts/` | The four audit scripts + `session2_constitution_counts.py` | The exact code that produced `02-` and the counting evidence |
| `MANIFEST.sha256` | SHA-256 of every bundled file | Generated at pack time |
| `verifier.sh` | Portable verifier (no GitHub network needed; locale pinned) | Verifies manifest, bundles, tips, pinned blobs, counting conventions incl. word counts |
| `reproduce-clean-checkout.sh` | Full clean-checkout reproduction | Re-clones, re-verifies, re-runs the 40-target audit, compares totals |
| `reproduction-log.txt` | Actual output log of the r1 reproduction run (historical; the `[N/40]` tokens therein are row indices, not claims) | 2026-10-19 session artifact |
| `r2-CHANGELOG.md` | Exact change list r1 → r2 mapped to auditor tasks T1–T10 | This revision |

## Headline results (all row-derived; see `02-`)

- **Corrected pass-eligibility record (T5):** "at most 20 of 40 could pass"
  was the auditor's earlier un-recomputed bound. The tracked artifact
  `docs/audit-evidence/2026-10-19/science-validity/independent_recompute_20_of_40.json`
  (blob `6cda70e2…` @ `science/p0-correctness-2026-10-19`) shows **0 of 40**
  could pass under the recorded v23 rows and the current modality matrix —
  38 blocked by LAW-120 at 10°, 2 by LAW-170 (1I0T, 1DDL). **Historical,
  recorded-v23-run figures.** "20 of 40" no longer appears as a
  pass-eligibility claim anywhere in this bundle.
- **C1 descriptive errors: 22/40** (21 identity + 1 ligation-state) —
  includes the auditor-corroborated 1EJG, 3NIR, 1I0T, 2VB1 and 17 further
  RCSB-verified identity errors (e.g., 1PPE = bovine β-trypsin + CMTI-I, not
  porcine elastase; 2KOX/2MJB = ubiquitin, not GB1/amyloid-β)
- **C2 method 5/40; resolution 24/40 strict / 23/40 @0.01 Å** (strict and
  tolerant always reported independently)
- **C3 eligibility 2/40** (1I0T Z-DNA nucleic-acid-only; 1DDL tymovirus
  protein+RNA)
- **C4 parse failures 0/40** (measurement re-run NOT performed — hard stop)
- **C5 coordinate-byte mismatches vs v24 manifest: 0/40** (acquisition
  stability only — never cohort-label validity; OD-17)
- **32/40 rows carry ≥1 metadata defect; 8 fully clean** (1AKE 1AON 1D3Z
  1GB1 1GFL 2JOF 2LYZ 3LZM)

## How to verify (exact commands)

```bash
# 1. hash the delivered bytes (compare against the values in the delivery
#    message — the archive ships its own hash out-of-band so you can catch
#    transport corruption):
sha256sum control-atlas-evidence-2026-10-20-round9-r2.tar.gz

# 2. extract:
mkdir round9r2 && tar -xzf control-atlas-evidence-2026-10-20-round9-r2.tar.gz -C round9r2
cd round9r2

# 3. run the portable verifier (no GitHub access needed; locale pinned to
#    C.UTF-8 by the script itself):
bash verifier.sh

# 4. optionally re-check the 4 exemplar coordinates against live RCSB:
bash verifier.sh --network

# 5. full clean-checkout reproduction (network; writes only under its
#    workdir):
bash reproduce-clean-checkout.sh /tmp/repro-round9
```

The verifier checks: every file against `MANIFEST.sha256`; all six git
bundles valid with pinned tips; the four pinned governance blobs
(`constitution.md`, `ENGINEERING_CONSTITUTION.md`, `dataset_v23.py`,
`P0_STATUS.md`) inside the bundled git data; both constitution counting
conventions byte-exact under the single pinned convention — **bytes,
UTF-8 characters, whitespace-split words (84 / 2,784), and line counts
(11/12/9 and 178/179/129, labelled as line counts, never words)** — under
`LC_ALL=C.UTF-8`.

## Delivery route (auditor T6)

The archive is delivered through the audit environment's durable download
channel (`/home/z/my-project/download/` in the coder sandbox — the only
channel reachable from this environment), together with its size, SHA-256,
manifest, and this verifier, so any third party can check the bytes without
the coder's workspace. GitHub release-asset publication is **not possible**
from this sandbox (no credentials; hard stop: no pushes) — the git bundles
in `06-git-bundles/` carry the same remote history in verifiable form.
Both archives (r1 and r2) are delivered side by side with exact hashes.

## Status discipline (summary)

- Everything in `02-` is `MEASURED` with bundled raw evidence and
  re-runnable scripts.
- Everything attributed to the prior session's transcript (N7 paired
  figures, N8 series, prior archive, prior QA) is `CODER_REPORTED` or
  `LOST` — stated as such, never presented as verified (`03-`, `08-`).
- OD-17…OD-21 are **recorded directives, OPEN, unimplemented** (T3). No
  owner approval is asserted for anything in this bundle.
- The word target is **UNCONFIRMED**; no number chosen (OD-21, T4).
- The hard stop on PR #16 (open/unmerged, 49 files, head `296f10c`;
  re-confirmed by this session's no-op fetch — no ref movement, no new
  remote branches) remains in effect. No push, merge, deployment,
  calibration, held-out evaluation, threshold change, cohort change, or
  golden-artifact regeneration was performed or is authorized.
- Per the auditor's direction: local verification success is **not**
  independent acceptance. The auditor must run these commands on
  independently delivered bytes.
