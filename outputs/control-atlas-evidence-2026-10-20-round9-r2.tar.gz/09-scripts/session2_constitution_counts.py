#!/usr/bin/env python3
"""Session-2 (2026-10-20) constitution counting-convention re-derivation.

Reads the exact pinned blobs dumped from the read-only clone and recomputes
the counting conventions used across all audit rounds:
  bytes, chars (UTF-8), LF count, split('\n') elements, non-blank lines,
  git blob SHA-1 (cross-checked with git hash-object by the caller).
"""
import hashlib
import pathlib

BASE = pathlib.Path("/home/z/my-project/work/verify-r9/session-read")

DOCS = {
    "constitution.domain.md": "211ad2c5d4b40059d9f3f03de12e0701f9235bc7",
    "ENGINEERING_CONSTITUTION.md": "b6bb35e84956d84a8c9d9e65734c212baf3ed075",
}

for name, expected in DOCS.items():
    data = (BASE / name).read_bytes()
    text = data.decode("utf-8")
    blob_sha = hashlib.sha1(b"blob %d\x00" % len(data) + data).hexdigest()
    counts = {
        "bytes": len(data),
        "chars": len(text),
        "LF": text.count("\n"),
        "split_elements": len(text.split("\n")),
        "nonblank_lines": sum(1 for ln in text.split("\n") if ln.strip()),
    }
    match = "MATCH" if blob_sha == expected else "MISMATCH"
    print(f"{name}: {counts} blob={blob_sha} expected={expected} -> {match}")
