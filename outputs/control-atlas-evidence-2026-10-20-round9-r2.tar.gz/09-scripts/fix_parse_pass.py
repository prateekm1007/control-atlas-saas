#!/usr/bin/env python3
"""Fix pass: correct EXPDTA record parsing + entity-count keys; re-derive from
saved raw evidence (no re-download). Updates fresh_audit.json in place -> v2."""
import json
import os
import re

EV = "/home/z/my-project/work/audit-evidence"
audit = json.load(open(os.path.join(EV, "fresh_audit.json")))
rows = audit["rows"]


def parse_pdb_text(text):
    lines = text.splitlines()
    title_parts, expdta, resolution_lines = [], [], []
    n_atom = n_ca = n_model = n_endmdl = n_hetatm = 0
    altloc_chars, insertion_codes, het_residues = set(), set(), set()
    parse_errors = []
    seen_end = False
    for ln in lines:
        rec = ln[:6]
        if rec == "TITLE ":
            title_parts.append(ln[10:].strip())
        elif rec == "EXPDTA":
            expdta.append(ln[10:].strip())
        elif rec == "REMARK" and ln[3:10] == "   2   " or (rec == "REMARK" and ln.startswith("REMARK   2")):
            if "RESOLUTION" in ln:
                resolution_lines.append(ln.strip())
        elif rec == "ATOM  ":
            n_atom += 1
            if len(ln) >= 80 and ln[12:16].strip() == "CA":
                n_ca += 1
            if len(ln) >= 17 and ln[16] != " ":
                altloc_chars.add(ln[16])
            if len(ln) >= 27 and ln[26] != " ":
                insertion_codes.add(ln[26])
        elif rec == "HETATM":
            n_hetatm += 1
            if len(ln) >= 20:
                het_residues.add(ln[17:20].strip())
        elif rec == "MODEL ":
            n_model += 1
        elif rec == "ENDMDL":
            n_endmdl += 1
        elif rec == "END   ":
            seen_end = True
    if n_atom == 0:
        parse_errors.append("no ATOM records")
    if not title_parts:
        parse_errors.append("no TITLE record")
    if not expdta:
        parse_errors.append("no EXPDTA record")
    if n_model > 0 and n_model != n_endmdl:
        parse_errors.append(f"MODEL({n_model})/ENDMDL({n_endmdl}) mismatch")
    if not seen_end:
        parse_errors.append("no END record")
    m = None
    if resolution_lines:
        mm = re.search(r"RESOLUTION\.\s+([0-9.]+)\s+ANGSTROM", resolution_lines[0])
        if mm:
            m = float(mm.group(1))
        elif "NOT APPLICABLE" in resolution_lines[0]:
            m = None
        else:
            parse_errors.append("unparseable REMARK 2 RESOLUTION: " + resolution_lines[0])
    return {
        "title_from_file": " ".join(title_parts),
        "method_from_file": "; ".join(expdta),
        "resolution_from_file_remark2": m,
        "n_atom": n_atom,
        "n_ca": n_ca,
        "n_hetatm": n_hetatm,
        "n_model": n_model,
        "altloc_chars": sorted(altloc_chars),
        "insertion_codes": sorted(insertion_codes),
        "het_residue_types": sorted(het_residues),
        "parse_errors": parse_errors,
    }


changed = 0
for pid, row in rows.items():
    # 1. re-parse coordinates with fixed EXPDTA
    path = os.path.join(EV, "coordinates", f"{pid}.pdb")
    text = open(path, "r", errors="strict").read()
    row["pdb_parse"] = parse_pdb_text(text)
    row["pdb_parse"]["decode"] = "ascii_ok"
    # 2. entity class with correct RCSB keys
    d = json.load(open(os.path.join(EV, "rcsb-api", f"{pid}.entry.json")))
    ei = d["rcsb_entry_info"]
    n_prot = ei.get("polymer_entity_count_protein") or 0
    n_dna = ei.get("polymer_entity_count_DNA") or ei.get("polymer_entity_count_dna") or 0
    n_rna = ei.get("polymer_entity_count_RNA") or ei.get("polymer_entity_count_rna") or 0
    row["official"]["polymer_entity_count_DNA"] = n_dna
    row["official"]["polymer_entity_count_RNA"] = n_rna
    if n_prot == 0 and (n_dna + n_rna) > 0:
        row["checks"]["entity_class"] = "nucleic_acid_only"
    elif n_prot > 0 and (n_dna + n_rna) > 0:
        row["checks"]["entity_class"] = "mixed_protein_nucleic_acid"
    elif n_prot == 0 and (n_dna + n_rna) == 0:
        row["checks"]["entity_class"] = "no_polymer_entities"
    else:
        row["checks"]["entity_class"] = "protein_only"
    changed += 1

audit["fix_pass"] = {
    "description": "EXPDTA 6-char record fix; polymer_entity_count_DNA/_RNA case-sensitive keys",
    "source": "re-derived from saved raw files, no re-download",
}
with open(os.path.join(EV, "fresh_audit.json"), "w") as f:
    json.dump(audit, f, indent=1, sort_keys=True)

# summary
from collections import Counter
print("entity classes:", Counter(r["checks"]["entity_class"] for r in rows.values()))
print("parse errors:", sum(1 for r in rows.values() if r["pdb_parse"]["parse_errors"]))
pe = [(p, r["pdb_parse"]["parse_errors"]) for p, r in sorted(rows.items()) if r["pdb_parse"]["parse_errors"]]
print(pe)
print("EXPDTA now present for:", sum(1 for r in rows.values() if r["pdb_parse"]["method_from_file"]))
# file-level method vs recorded category
METHOD_BY_CATEGORY = {
    "xray_ultrahigh": ["X-RAY DIFFRACTION"], "xray_medium": ["X-RAY DIFFRACTION"],
    "xray_low": ["X-RAY DIFFRACTION"], "cryo_em": ["ELECTRON MICROSCOPY"], "nmr": ["SOLUTION NMR"],
}
fm = []
for pid, r in sorted(rows.items()):
    cat = r["recorded"]["category"]
    filem = r["pdb_parse"]["method_from_file"]
    if not all(any(c in filem for c in METHOD_BY_CATEGORY[cat]) for c in [x for x in METHOD_BY_CATEGORY[cat]]):
        fm.append((pid, cat, filem))
print("file-EXPDTA method mismatches:", fm)
# file REMARK2 resolution vs recorded
fr = []
for pid, r in sorted(rows.items()):
    rec = r["recorded"]["resolution"]
    fres = r["pdb_parse"]["resolution_from_file_remark2"]
    if rec is None:
        bad = fres is not None
    else:
        bad = fres is None or abs(fres - rec) > 0.005
    if bad:
        fr.append((pid, rec, fres))
print("file-REMARK2 resolution mismatches (strict):", len(fr))
print(fr)
