#!/usr/bin/env python3
"""
Adjudication pass: build the item-level 40-target discrepancy table (OD-16 / N7).

Classification rules (documented, applied uniformly):
  C1 descriptive metadata:
     identity_error - recorded desc names a DIFFERENT molecular system than the
                      official RCSB structure
     state_error    - recorded desc asserts a specific ligation/assembly state
                      contradicted by the official structure (e.g. deoxy vs oxy)
     match          - same molecular system, no false specific claim
     (imprecise-but-true notes recorded separately, not counted as errors)
  C2 method/resolution:
     method     - category-implied method vs official EXPDTL method
     resolution - recorded vs official resolution_combined[0]
                  strict: |diff| > 0.005 A ; tolerant: > 0.01 A
  C3 entity/eligibility (actual acquired structure vs protein-only protocol):
     nucleic_acid_only / mixed_protein_nucleic_acid / protein_only
  C4 parse-level: failures from PDB record parse (0 = clean); informational
     anomalies (multi-model, altloc, insertion codes) recorded, not errors.
     Measurement-level re-run NOT performed (hard stop; historical logs lost).
  C5 coordinate bytes: fresh SHA-256 vs v24 coordinate_manifest.json SHA-256.

Derives all totals from rows. Emits JSON + Markdown table.
"""
import json
import os
from datetime import datetime, timezone

EV = "/home/z/my-project/work/audit-evidence"
audit = json.load(open(os.path.join(EV, "fresh_audit.json")))
rows = audit["rows"]

# ---- C1 adjudication (per-ID, with rationale) -------------------------------
# Rule: identity_error = desc names a different molecular system.
#       state_error = desc asserts a contradicted specific state.
ADJ = {
    "1AKE": ("match", "adenylate kinase = official title"),
    "1AON": ("match", "GroEL/GroES complex = official title"),
    "1BPI": ("match", "BPTI is the standard abbreviation of the official title"),
    "1BRS": ("match", "barnase-barstar complex = official title"),
    "1D3Z": ("match", "ubiquitin NMR = official title"),
    "1DDL": ("identity_error", "recorded 'Dihydroorotase'; official structure is Desmodium yellow mottle tymovirus (virus particle, protein+RNA)"),
    "1EJG": ("identity_error", "recorded 'Cholesterol oxidase'; official structure is crambin [AUDITOR-CORROBORATED]"),
    "1FIN": ("match", "CDK2-cyclin A = cyclin A-CDK2 complex (same complex, component order swapped)"),
    "1GB1": ("match", "protein G B1 = immunoglobulin-binding domain of protein G"),
    "1GCI": ("identity_error", "recorded 'Glucose isomerase'; official structure is a serine protease (Bacillus lentus subtilisin) at 0.78 A"),
    "1GFL": ("match", "GFP = green fluorescent protein"),
    "1HHO": ("state_error", "recorded 'Deoxyhemoglobin'; official structure is human OXYhaemoglobin (ligation state contradicted)"),
    "1I0T": ("identity_error", "recorded 'Ferredoxin'; official structure is Z-DNA hexamer CGCGCG (nucleic acid, not a protein) [AUDITOR-CORROBORATED]"),
    "1L2Y": ("identity_error", "recorded 'Villin headpiece'; official structure is Trp-cage miniprotein TC5b"),
    "1MBO": ("match", "'Myoglobin' does not assert a state; official is oxymyoglobin (imprecision noted, resolution error counted in C2)"),
    "1NEK": ("identity_error", "recorded 'Nek2 kinase'; official structure is E. coli Complex II / succinate dehydrogenase"),
    "1PPE": ("identity_error", "recorded 'Porcine elastase'; official structure is bovine beta-trypsin + CMTI-I squash-seed inhibitor complex"),
    "1RVS": ("identity_error", "recorded 'BPTI NMR'; official structure is transthyretin amyloid fibrils (solid-state MAS NMR)"),
    "1TEN": ("match", "tenascin = fibronectin type III domain from tenascin"),
    "2ACE": ("match", "acetylcholinesterase = official title (resolution error counted in C2)"),
    "2CBA": ("match", "carbonic anhydrase = carbonic anhydrase II (resolution error counted in C2)"),
    "2HBS": ("match", "sickle-cell hemoglobin = deoxyhemoglobin S (resolution error counted in C2)"),
    "2JOF": ("match", "Trp-cage miniprotein = official title"),
    "2KOX": ("identity_error", "recorded 'GB1 domain NMR'; official structure is ubiquitin (76-residue canonical sequence, entity description 'Ubiquitin')"),
    "2LYZ": ("match", "hen lysozyme = hen egg-white lysozyme"),
    "2MJB": ("identity_error", "recorded 'Amyloid beta NMR'; official structure is ubiquitin(-L40 fusion) solution NMR"),
    "2N0A": ("match", "alpha-synuclein = official molecule; fibril state + solid-state NMR recorded as imprecision (method subclass error counted in C2)"),
    "2OV0": ("identity_error", "recorded 'Lysozyme ultra-high'; official structure is amicyanin (blue copper protein)"),
    "2VB1": ("identity_error", "recorded 'Crambin ultra-high res'; official structure is hen egg-white lysozyme (HEWL) at 0.65 A [AUDITOR-CORROBORATED]"),
    "3J9I": ("identity_error", "recorded '80S ribosome'; official structure is T. acidophilum 20S proteasome"),
    "3LZM": ("match", "T4 lysozyme = official title"),
    "3NIR": ("identity_error", "recorded 'Concanavalin A'; official structure is crambin at 0.48 A [AUDITOR-CORROBORATED]"),
    "3PGK": ("match", "phosphoglycerate kinase = yeast PGK (resolution error counted in C2)"),
    "5A63": ("identity_error", "recorded 'TRPV1 channel'; official structure is human gamma-secretase complex"),
    "5T4O": ("identity_error", "recorded 'Spliceosome'; official structure is E. coli ATP synthase (autoinhibited, 6.9 A)"),
    "6J6J": ("identity_error", "recorded 'Human 26S proteasome'; official structure is biotin-bound streptavidin"),
    "6NB6": ("identity_error", "recorded 'ABC transporter'; official structure is SARS-CoV + human S230 antibody Fab complex"),
    "6WLC": ("identity_error", "recorded 'SARS-CoV-2 nucleocapsid'; official structure is SARS-CoV-2 NSP15 endoribonuclease (X-ray, 1.82 A)"),
    "7JTL": ("identity_error", "recorded 'SARS-CoV-2 RBD-ACE2'; official structure is SARS-CoV-2 ORF8 accessory protein (X-ray)"),
    "7K3G": ("identity_error", "recorded 'SARS-CoV-2 spike closed'; official structure is SARS-CoV-2 envelope protein TMD pentamer (solid-state NMR)"),
}
assert set(ADJ) == set(rows), "adjudication must cover all 40"

IMPRECISE_NOTES = {
    "1MBO": "official structure is OXYmyoglobin; recorded 'Myoglobin' asserts no state",
    "2N0A": "official structure is fibrillar (solid-state NMR); recorded implies solution NMR by category",
}

METHOD_BY_CATEGORY = {
    "xray_ultrahigh": "X-RAY DIFFRACTION", "xray_medium": "X-RAY DIFFRACTION",
    "xray_low": "X-RAY DIFFRACTION", "cryo_em": "ELECTRON MICROSCOPY",
    "nmr": "SOLUTION NMR",
}

out_rows = []
for pid in sorted(rows):
    r = rows[pid]
    rec = r["recorded"]
    off = r["official"]
    pp = r["pdb_parse"]
    cf = r["coordinate_fetch"]
    c1, c1_note = ADJ[pid]
    # C2
    off_res = off["resolution_combined"][0] if off["resolution_combined"] else None
    rec_res = rec["resolution"]
    method_mm = r["checks"]["method_mismatch"]
    if rec_res is None:
        res_mm_strict = off_res is not None
        res_mm_tol = off_res is not None
    else:
        res_mm_strict = off_res is None or abs(off_res - rec_res) > 0.005 + 1e-9
        res_mm_tol = off_res is None or abs(off_res - rec_res) > 0.01 + 1e-9
    # C3
    eclass = r["checks"]["entity_class"]
    # C5
    byte_match = cf.get("byte_match_v24")
    row = {
        "pdb_id": pid,
        "recorded_category": rec["category"],
        "recorded_desc": rec["desc"],
        "recorded_resolution": rec_res,
        "official_title": off["title"],
        "official_methods": off["methods"],
        "official_resolution": off_res,
        "official_entity_class": eclass,
        "official_entities": [
            {"id": e["entity_id"], "type": e.get("poly_type"), "desc": e.get("description")}
            for e in off["entities"]
        ],
        "deposited_at": off["deposited_at"],
        "revision_at": off["revision_at"],
        "c1_descriptive": c1,
        "c1_rationale": c1_note,
        "c1_imprecise_note": IMPRECISE_NOTES.get(pid),
        "c2_method_mismatch": method_mm,
        "c2_resolution_mismatch_strict": res_mm_strict,
        "c2_resolution_mismatch_tol001": res_mm_tol,
        "c3_eligibility": (
            "INELIGIBLE_protein_only" if eclass == "nucleic_acid_only"
            else "INELIGIBLE_BY_DEFAULT_pending_criteria" if eclass == "mixed_protein_nucleic_acid"
            else "protein_only"
        ),
        "c4_parse_failures": pp["parse_errors"],
        "c4_anomalies": {
            "n_model": pp["n_model"], "altloc_chars": pp["altloc_chars"],
            "insertion_codes": pp["insertion_codes"],
            "n_atom": pp["n_atom"], "n_hetatm": pp["n_hetatm"],
        },
        "c5_coordinate_sha256_fresh": cf["sha256_fresh"],
        "c5_coordinate_sha256_v24": cf["v24_sha256"],
        "c5_bytes_fresh": cf["bytes"],
        "c5_bytes_v24": cf["v24_bytes"],
        "c5_byte_match_v24": byte_match,
        "api_response_sha256": r["api_response_sha256"],
    }
    out_rows.append(row)

# ---- totals derived from rows ----------------------------------------------
def count(f):
    return sum(1 for r in out_rows if f(r))

totals = {
    "experimental_total": len(out_rows),
    "c1_descriptive_errors": count(lambda r: r["c1_descriptive"] in ("identity_error", "state_error")),
    "c1_identity_errors": count(lambda r: r["c1_descriptive"] == "identity_error"),
    "c1_state_errors": count(lambda r: r["c1_descriptive"] == "state_error"),
    "c2_method_mismatches": count(lambda r: r["c2_method_mismatch"]),
    "c2_resolution_mismatches_strict": count(lambda r: r["c2_resolution_mismatch_strict"]),
    "c2_resolution_mismatches_tol001": count(lambda r: r["c2_resolution_mismatch_tol001"]),
    "c2_method_or_resolution_strict": count(lambda r: r["c2_method_mismatch"] or r["c2_resolution_mismatch_strict"]),
    "c2_method_or_resolution_tol001": count(lambda r: r["c2_method_mismatch"] or r["c2_resolution_mismatch_tol001"]),
    "c3_nucleic_acid_only": count(lambda r: r["official_entity_class"] == "nucleic_acid_only"),
    "c3_mixed_protein_nucleic": count(lambda r: r["official_entity_class"] == "mixed_protein_nucleic_acid"),
    "c4_parse_failures": count(lambda r: r["c4_parse_failures"]),
    "c5_coordinate_byte_mismatches": count(lambda r: not r["c5_byte_match_v24"]),
    "any_metadata_defect": count(lambda r: (
        r["c1_descriptive"] in ("identity_error", "state_error")
        or r["c2_method_mismatch"] or r["c2_resolution_mismatch_strict"]
        or r["c3_eligibility"] != "protein_only")),
    "fully_clean_rows": [r["pdb_id"] for r in out_rows if not (
        r["c1_descriptive"] in ("identity_error", "state_error")
        or r["c2_method_mismatch"] or r["c2_resolution_mismatch_strict"]
        or r["c3_eligibility"] != "protein_only")],
}

result = {
    "generated_utc": datetime.now(timezone.utc).isoformat(),
    "dataset_v23_blob_sha1": "3a5358374b2037b9475bd2d494754944485da5ac",
    "classification_rules": {
        "c1": "identity_error = recorded desc names a different molecular system; state_error = recorded desc asserts a contradicted ligation/assembly state; imprecise-but-true recorded as notes only",
        "c2_resolution": "recorded vs official resolution_combined[0]; strict |diff|>0.005 A; tolerant |diff|>0.01 A",
        "c2_method": "category-implied method (xray->X-RAY DIFFRACTION, cryo_em->ELECTRON MICROSCOPY, nmr->SOLUTION NMR) vs official EXPDTL",
        "c3": "entity class of the ACTUAL acquired structure vs a protein-only calibration protocol",
        "c4": "PDB record-level parse failures; anomalies informational; measurement re-run NOT performed (hard stop)",
        "c5": "fresh SHA-256 of https://files.rcsb.org/download/{id}.pdb vs v24 coordinate_manifest.json SHA-256",
    },
    "totals": totals,
    "rows": out_rows,
}
with open(os.path.join(EV, "n7_od16_40target_table.json"), "w") as f:
    json.dump(result, f, indent=1)

print(json.dumps(totals, indent=2))
print()
print("clean rows:", totals["fully_clean_rows"])
