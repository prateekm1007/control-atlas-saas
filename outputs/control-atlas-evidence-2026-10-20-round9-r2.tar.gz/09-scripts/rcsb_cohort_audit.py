#!/usr/bin/env python3
"""
RCSB cohort-metadata audit for dataset_v23.py (OD-16 evidence collection).

Purpose (diagnostic only, per auditor Round-9 directions 2-3):
  For every EXPERIMENTAL target recorded in the pinned dataset_v23.py
  (blob 3a5358374b2037b9475bd2d494754944485da5ac), collect:
    - official RCSB title, experimental method, resolution
    - polymer entity identity (protein / DNA / RNA counts, entity descriptions)
    - source revision date
    - fresh downloaded coordinate bytes + SHA-256
    - comparison of fresh digest vs historical v24 coordinate_manifest.json digest
    - PDB file parse-level checks (records, models, altlocs, insertion codes)

This script performs NO calibration, NO threshold derivation, NO verdict issuance.
It is a metadata/discrepancy audit only. The v23 dataset and its historical
results are preserved unchanged (quarantine disposition OD-16).

Outputs:
  work/audit-evidence/rcsb-api/{id}.entry.json        raw API responses
  work/audit-evidence/rcsb-api/{id}.entity{n}.json    raw entity responses
  work/audit-evidence/coordinates/{id}.pdb            downloaded coordinates
  work/audit-evidence/fresh_audit.json                full row-level results
"""
import hashlib
import json
import os
import re
import sys
import time
import datetime

import requests

BASE = "/home/z/my-project/work"
EV = os.path.join(BASE, "audit-evidence")
API_DIR = os.path.join(EV, "rcsb-api")
COORD_DIR = os.path.join(EV, "coordinates")
os.makedirs(API_DIR, exist_ok=True)
os.makedirs(COORD_DIR, exist_ok=True)

ENTRY_URL = "https://data.rcsb.org/rest/v1/core/entry/{}"
ENTITY_URL = "https://data.rcsb.org/rest/v1/core/polymer_entity/{}/{}"
FILE_URL = "https://files.rcsb.org/download/{}.pdb"

SESSION = requests.Session()
SESSION.headers.update({"User-Agent": "control-atlas-audit/1.0 (cohort metadata verification)"})

# --- load recorded dataset (experimental entries only) -----------------------
sys.path.insert(0, BASE)
import importlib.util
spec = importlib.util.spec_from_file_location("dataset_v23", os.path.join(BASE, "dataset_v23.py"))
ds = importlib.util.module_from_spec(spec)
spec.loader.exec_module(ds)

recorded = {}  # pdb_id -> dict(cat, resolution, desc)
for cat, entries in ds.CALIBRATION_DATASET.items():
    if cat == "predicted":
        continue  # experimental only, per direction 3
    for e in entries:
        recorded[e["pdb_id"]] = {
            "category": cat,
            "resolution": e["resolution"],
            "desc": e["desc"],
        }
assert len(recorded) == 40, f"expected 40 experimental targets, got {len(recorded)}"

# --- load historical v24 manifest -------------------------------------------
v24 = json.load(open(os.path.join(BASE, "coordinate_manifest_v24.json")))

METHOD_BY_CATEGORY = {
    "xray_ultrahigh": ["X-RAY DIFFRACTION"],
    "xray_medium": ["X-RAY DIFFRACTION"],
    "xray_low": ["X-RAY DIFFRACTION"],
    "cryo_em": ["ELECTRON MICROSCOPY"],
    "nmr": ["SOLUTION NMR"],
}


def sha256_bytes(b):
    return hashlib.sha256(b).hexdigest()


def get_json(url, tries=4):
    last = None
    for i in range(tries):
        try:
            r = SESSION.get(url, timeout=40)
            if r.status_code == 200:
                return r.json(), r.content
            last = f"HTTP {r.status_code}"
        except Exception as e:  # noqa: BLE001
            last = repr(e)
        time.sleep(2.0 * (i + 1))
    return None, last


def get_bytes(url, tries=4):
    last = None
    for i in range(tries):
        try:
            r = SESSION.get(url, timeout=120)
            if r.status_code == 200:
                return r.content, None
            last = f"HTTP {r.status_code}"
        except Exception as e:  # noqa: BLE001
            last = repr(e)
        time.sleep(3.0 * (i + 1))
    return None, last


def parse_pdb_text(text):
    """Strict-ish PDB header/parse diagnostic. Returns dict of parse findings."""
    lines = text.splitlines()
    title_parts, expdta, resolution_lines = [], [], []
    n_atom = n_ca = n_model = n_endmdl = n_hetatm = 0
    altloc_chars = set()
    insertion_codes = set()
    het_residues = set()
    parse_errors = []
    seen_end = False
    for ln in lines:
        rec = ln[:6]
        if rec == "TITLE ":
            title_parts.append(ln[10:].strip())
        elif rec == "EXPDTA ":
            expdta.append(ln[10:].strip())
        elif rec == "REMARK   2":
            if "RESOLUTION" in ln:
                resolution_lines.append(ln.strip())
        elif rec == "ATOM  " or rec == "HETATM":
            if rec == "ATOM  ":
                n_atom += 1
                if len(ln) >= 80 and ln[12:16].strip() == "CA":
                    n_ca += 1
                if len(ln) >= 17 and ln[16] != " ":
                    altloc_chars.add(ln[16])
                if len(ln) >= 27 and ln[26] != " ":
                    insertion_codes.add(ln[26])
            else:
                n_hetatm += 1
                if len(ln) >= 20:
                    het_residues.add(ln[17:20].strip())
        elif rec == "MODEL ":
            n_model += 1
        elif rec == "ENDMDL":
            n_endmdl += 1
        elif rec == "END   ":
            seen_end = True
    # parse-level anomaly checks
    if n_atom == 0:
        parse_errors.append("no ATOM records")
    if not title_parts:
        parse_errors.append("no TITLE record")
    if not expdta:
        parse_errors.append("no EXPDTA record")
    if n_model > 0 and n_model != n_endmdl:
        parse_errors.append(f"MODEL({n_model})/ENDMDL({n_endmdl}) mismatch")
    if not seen_end:
        parse_errors.append("no END record")
    m = None
    if resolution_lines:
        mm = re.search(r"RESOLUTION\.\s+([0-9.]+)\s+ANGSTROM", resolution_lines[0])
        if mm:
            m = float(mm.group(1))
        elif "NOT APPLICABLE" in resolution_lines[0]:
            m = None
        else:
            parse_errors.append("unparseable REMARK 2 RESOLUTION: " + resolution_lines[0])
    return {
        "title_from_file": " ".join(title_parts),
        "method_from_file": "; ".join(expdta),
        "resolution_from_file_remark2": m,
        "n_atom": n_atom,
        "n_ca": n_ca,
        "n_hetatm": n_hetatm,
        "n_model": n_model,
        "altloc_chars": sorted(altloc_chars),
        "insertion_codes": sorted(insertion_codes),
        "het_residue_types": sorted(het_residues),
        "parse_errors": parse_errors,
    }


def main():
    results = {}
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    for i, (pid, rec) in enumerate(sorted(recorded.items()), 1):
        row = {
            "pdb_id": pid,
            "recorded": rec,
            "fetch_started_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        }
        # 1. entry metadata
        ej, raw = get_json(ENTRY_URL.format(pid))
        if ej is None:
            row["api_status"] = f"FAILED: {raw}"
            results[pid] = row
            print(f"[{i:2d}/40] {pid}: API FAILED {raw}")
            continue
        with open(os.path.join(API_DIR, f"{pid}.entry.json"), "wb") as f:
            f.write(raw)
        row["api_response_sha256"] = sha256_bytes(raw)
        st = ej.get("struct", {})
        ei = ej.get("rcsb_entry_info", {})
        acc = ej.get("rcsb_accession_info", {})
        row["official"] = {
            "title": st.get("title"),
            "methods": [e.get("method") for e in ej.get("exptl", [])],
            "resolution_combined": ei.get("resolution_combined"),
            "polymer_entity_count": ei.get("polymer_entity_count"),
            "polymer_entity_count_protein": ei.get("polymer_entity_count_protein"),
            "polymer_entity_count_dna": ei.get("polymer_entity_count_dna"),
            "polymer_entity_count_rna": ei.get("polymer_entity_count_rna"),
            "deposited_at": (ej.get("rcsb_accession_info", {}) or {}).get("deposit_date"),
            "revision_at": (ej.get("rcsb_accession_info", {}) or {}).get("revision_date"),
        }
        # 2. polymer entity identities
        entities = []
        n_ent = ei.get("polymer_entity_count") or 0
        for ent_id in range(1, min(n_ent, 5) + 1):
            pj, praw = get_json(ENTITY_URL.format(pid, ent_id))
            if pj is None:
                entities.append({"entity_id": ent_id, "fetch": f"FAILED: {praw}"})
                continue
            with open(os.path.join(API_DIR, f"{pid}.entity{ent_id}.json"), "wb") as f:
                f.write(praw)
            pdesc = (pj.get("rcsb_polymer_entity", {}) or {}).get("pdbx_description")
            ptype = (pj.get("entity_poly", {}) or {}).get("type")
            seq_nc = (pj.get("entity_poly", {}) or {}).get("pdbx_seq_one_letter_code_can")
            entities.append({
                "entity_id": ent_id,
                "description": pdesc,
                "poly_type": ptype,
                "can_seq_len": len(seq_nc) if seq_nc else None,
            })
            time.sleep(0.2)
        row["official"]["entities"] = entities
        # 3. coordinates
        coord, err = get_bytes(FILE_URL.format(pid))
        if coord is None:
            row["coordinate_fetch"] = {"status": f"FAILED: {err}"}
        else:
            csha = sha256_bytes(coord)
            with open(os.path.join(COORD_DIR, f"{pid}.pdb"), "wb") as f:
                f.write(coord)
            hist = v24.get(pid, {})
            row["coordinate_fetch"] = {
                "status": "ok",
                "bytes": len(coord),
                "sha256_fresh": csha,
                "v24_sha256": hist.get("sha256"),
                "v24_bytes": hist.get("bytes"),
                "v24_fetched_at": hist.get("fetched_at_utc"),
                "v24_status": hist.get("acquisition_status"),
                "byte_match_v24": (hist.get("sha256") == csha),
            }
            try:
                text = coord.decode("ascii")
                row["pdb_parse"] = parse_pdb_text(text)
                row["pdb_parse"]["decode"] = "ascii_ok"
            except UnicodeDecodeError as ude:
                row["pdb_parse"] = {"decode": f"ascii_fail: {ude}"}
        # 4. mechanical comparisons
        off = row["official"]
        # method
        cat_methods = METHOD_BY_CATEGORY[rec["category"]]
        off_methods = [m for m in off["methods"] if m]
        row["checks"] = {}
        row["checks"]["method_mismatch"] = not all(any(
            cm in om for om in off_methods) for cm in cat_methods) or not off_methods
        # resolution (2 dp; None for NMR)
        off_res = off["resolution_combined"][0] if off["resolution_combined"] else None
        rec_res = rec["resolution"]
        if rec_res is None:
            row["checks"]["resolution_mismatch"] = off_res is not None
        else:
            row["checks"]["resolution_mismatch"] = (
                off_res is None or abs(off_res - rec_res) > 0.005
            )
        # entity eligibility for a protein-only protocol
        n_prot = off["polymer_entity_count_protein"] or 0
        n_dna = off["polymer_entity_count_dna"] or 0
        n_rna = off["polymer_entity_count_rna"] or 0
        if n_prot == 0 and (n_dna + n_rna) > 0:
            row["checks"]["entity_class"] = "nucleic_acid_only"
        elif n_prot > 0 and (n_dna + n_rna) > 0:
            row["checks"]["entity_class"] = "mixed_protein_nucleic_acid"
        elif n_prot == 0:
            row["checks"]["entity_class"] = "no_polymer_entities"
        else:
            row["checks"]["entity_class"] = "protein_only"
        row["fetch_finished_utc"] = datetime.datetime.now(datetime.timezone.utc).isoformat()
        results[pid] = row
        bm = row.get("coordinate_fetch", {}).get("byte_match_v24")
        print(f"[{i:2d}/40] {pid}: {off['title'][:60]!r} res={off_res} "
              f"method={off_methods} byte_match_v24={bm}")
        time.sleep(0.25)
    out = {
        "audit_started_utc": started,
        "audit_finished_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "dataset_blob_sha1": "3a5358374b2037b9475bd2d494754944485da5ac",
        "purpose": "OD-16 diagnostic metadata audit; no calibration, no thresholds, no verdicts",
        "rows": results,
    }
    with open(os.path.join(EV, "fresh_audit.json"), "w") as f:
        json.dump(out, f, indent=1, sort_keys=True)
    print("\nSaved", os.path.join(EV, "fresh_audit.json"))


if __name__ == "__main__":
    main()
