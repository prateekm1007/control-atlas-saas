#!/usr/bin/env python3
"""Render the 40-target item-level discrepancy table as Markdown."""
import json

SRC = "/home/z/my-project/work/audit-evidence/n7_od16_40target_table.json"
DST = "/home/z/my-project/work/evidence-r9/02-n7-od16-cohort-audit/n7_od16_40target_table.md"

d = json.load(open(SRC))
rows = d["rows"]
t = d["totals"]


def yes(b, sym_true="YES", sym_false="—"):
    return sym_true if b else sym_false


lines = []
lines.append("# N7 / OD-16 — Item-Level Discrepancy Table, All 40 Experimental Structures")
lines.append("")
lines.append(f"Generated UTC: {d['generated_utc']} · dataset_v23.py blob `3a5358374b2037b9475bd2d494754944485da5ac`")
lines.append("")
lines.append("All rows derive from fresh, this-session evidence: RCSB Data API entry/polymer-entity")
lines.append("responses and coordinate downloads from `https://files.rcsb.org/download/{id}.pdb`")
lines.append("(raw responses bundled in `rcsb-api/`, digests in the JSON table). Counts are derived")
lines.append("from these rows by script (`09-scripts/adjudicate_table.py`). No calibration, threshold")
lines.append("derivation, verdict issuance, cohort change, or golden-artifact regeneration was performed.")
lines.append("")
lines.append("## Column definitions")
lines.append("")
lines.append("| Column | Definition |")
lines.append("|---|---|")
lines.append("| C1 desc | `identity_error` = recorded `desc` names a different molecular system than the official RCSB structure; `state_error` = recorded desc asserts a contradicted ligation/assembly state; `match` = same system, no false specific claim |")
lines.append("| C2 method | recorded category-implied method (xray→X-RAY DIFFRACTION, cryo_em→ELECTRON MICROSCOPY, nmr→SOLUTION NMR) vs official EXPDTL method |")
lines.append("| C2 res | recorded `resolution` vs official `resolution_combined[0]`; strict: \\|Δ\\|>0.005 Å; tol: \\|Δ\\|>0.01 Å |")
lines.append("| C3 entity | polymer entity class of the ACTUAL acquired structure vs a protein-only calibration protocol |")
lines.append("| C4 parse | PDB record-level parse failures this session (parse anomalies recorded in JSON, informational) |")
lines.append("| C5 bytes | SHA-256 of fresh coordinate download vs `backend/calibration/runs/v24/coordinate_manifest.json` recorded digest |")
lines.append("")
lines.append("## Totals (derived from the rows below)")
lines.append("")
lines.append(f"- Experimental targets: **{t['experimental_total']}**")
lines.append(f"- C1 descriptive errors: **{t['c1_descriptive_errors']}/40** ({t['c1_identity_errors']} identity + {t['c1_state_errors']} ligation-state)")
lines.append(f"- C2 method mismatches: **{t['c2_method_mismatches']}/40**; resolution mismatches: **{t['c2_resolution_mismatches_strict']}/40 strict**, **{t['c2_resolution_mismatches_tol001']}/40** at 0.01 Å tolerance; combined method-or-resolution: **{t['c2_method_or_resolution_strict']}/40 strict** / **{t['c2_method_or_resolution_tol001']}/40 tolerant**")
lines.append(f"- C3 entity eligibility flags: **{t['c3_nucleic_acid_only'] + t['c3_mixed_protein_nucleic']}/40** ({t['c3_nucleic_acid_only']} nucleic-acid-only: 1I0T; {t['c3_mixed_protein_nucleic']} protein+RNA virus particle: 1DDL)")
lines.append(f"- C4 parse failures: **{t['c4_parse_failures']}/40** (measurement-level re-run NOT performed — hard stop; historical N7 measurement logs lost)")
lines.append(f"- C5 coordinate-byte mismatches vs v24 manifest: **{t['c5_coordinate_byte_mismatches']}/40**")
lines.append(f"- Rows with ≥1 metadata defect (C1∪C2∪C3): **{t['any_metadata_defect']}/40**; fully clean: **{len(t['fully_clean_rows'])}** ({', '.join(t['fully_clean_rows'])})")
lines.append("")
lines.append("## Item-level table (40 rows)")
lines.append("")
lines.append("| # | PDB | Recorded category | Recorded desc (dataset_v23.py) | Official RCSB title | Official method | Res rec→off (Å) | C1 desc | C2 method | C2 res | C3 entity | C4 parse | C5 bytes |")
lines.append("|---|---|---|---|---|---|---|---|---|---|---|---|---|")
for i, r in enumerate(rows, 1):
    pid = r["pdb_id"]
    res_rec = r["recorded_resolution"] if r["recorded_resolution"] is not None else "None"
    res_off = r["official_resolution"] if r["official_resolution"] is not None else "None"
    c1 = {"identity_error": "**IDENT**", "state_error": "**STATE**", "match": "ok"}[r["c1_descriptive"]]
    lines.append(
        f"| {i} | {pid} | {r['recorded_category']} | {r['recorded_desc']} | {r['official_title'][:95]} | "
        f"{'; '.join(r['official_methods'])} | {res_rec}→{res_off} | {c1} | "
        f"{'**MM**' if r['c2_method_mismatch'] else 'ok'} | "
        f"{'**RM**' if (r['c2_resolution_mismatch_strict'] and r['c2_resolution_mismatch_tol001']) else ('rm01' if r['c2_resolution_mismatch_strict'] else 'ok')} | "
        f"{r['c3_eligibility']} | {'FAIL' if r['c4_parse_failures'] else 'ok'} | "
        f"{'MISMATCH' if not r['c5_byte_match_v24'] else 'match'} |"
    )
lines.append("")
lines.append("Legend: IDENT = identity error; STATE = ligation-state error; MM = method mismatch;")
lines.append("RM = resolution mismatch (strict); rm01 = mismatch only under strict 0.005 Å rule")
lines.append("(1BPI: recorded 1.10 vs official 1.09); C3 values: `protein_only`,")
lines.append("`nucleic_acid_only` (INELIGIBLE for protein-only protocol),")
lines.append("`mixed_protein_nucleic_acid` (INELIGIBLE by default pending explicit criteria).")
lines.append("")
lines.append("## Per-row adjudication rationale (C1)")
lines.append("")
for r in rows:
    note = f" — *imprecision note:* {r['c1_imprecise_note']}" if r["c1_imprecise_note"] else ""
    lines.append(f"- **{r['pdb_id']}** [{r['c1_descriptive']}]: {r['c1_rationale']}{note}")
lines.append("")
lines.append("## Per-row provenance (source revision + digests)")
lines.append("")
lines.append("| PDB | RCSB revision (date) | API resp SHA-256 (entry) | Coord bytes (fresh=v24) | Coord SHA-256 (fresh=v24) |")
lines.append("|---|---|---|---|---|")
for r in rows:
    rev = (r["revision_at"] or "")[:10]
    lines.append(
        f"| {r['pdb_id']} | {rev} | `{r['api_response_sha256'][:16]}…` | "
        f"{r['c5_bytes_fresh']} = {r['c5_bytes_v24']} | `{r['c5_coordinate_sha256_fresh'][:16]}…` = `{(r['c5_coordinate_sha256_v24'] or '')[:16]}…` |"
    )
lines.append("")
lines.append("Full 64-hex digests, raw API responses, entity descriptions, deposited dates, parse")
lines.append("anomaly details (multi-model counts, altloc characters, insertion codes) are in")
lines.append("`n7_od16_40target_table.json` and `rcsb-api/`. Exemplar coordinate files for the four")
lines.append("auditor-corroborated cases (1EJG, 3NIR, 1I0T, 2VB1) are in `coordinates-exemplars/`.")
lines.append("")

open(DST, "w").write("\n".join(lines))
print("wrote", DST, "lines:", len(lines))
