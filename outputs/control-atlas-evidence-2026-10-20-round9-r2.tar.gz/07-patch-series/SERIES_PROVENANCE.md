# Patch Series Provenance — Original Remote History vs Lost Work

## What is in this directory (ALL of it: original remote history)

Every `.patch` file here was generated this session (2026-10-19T20:16Z) with
`git format-patch` from a **read-only clone** of
`github.com/prateekm1007/control-atlas-saas`. Every patch corresponds to a
commit that exists on a **verified remote branch** and inside a **verified
git bundle** (`../06-git-bundles/`). None of it is reconstructed, rebased,
edited, or re-authored.

| Series | Directory | Commits | Range | Branch tip (pinned) |
|---|---|---|---|---|
| P0 correctness program (incl. WP-1…WP-14 hardening, WP-SCI-1 science-validity, evidence set, P0 items 1–16) | `science-p0-correctness/` | 28 | `origin/main..origin/science/p0-correctness-2026-10-19` | `ebc1fd79f20b9a6b6a262a70ce6942ba069d19e9` |
| PR #16 content (WP-SCI-1 + evidence) | `science-law-validity-wp15/` | 2 | `origin/integration/p0-hardening-2026-10-19..origin/science/law-validity-wp15` | `296f10c4f2c87df2003c1a9d0150edc0b54a13d9` |
| Hygiene (nested-copy removal, test isolation) | `chore-hygiene/` | 2 | `296f10c..origin/chore/hygiene-2026-10-19` | `abc450ea45183e9cebf3da8a6e20878d2d18a1bf` |
| Engineering Constitution adoption (WP-11) | `policy-engineering-constitution/` | 1 | `origin/main..origin/policy/engineering-constitution` | `4993cb3b6954ffb8ecad281817b2c59f1f8fc041` |

Cross-checks performed this session:
- PR #16 verified via GitHub web: open/unmerged, base
  `integration/p0-hardening-2026-10-19`, head `science/law-validity-wp15`,
  **49 changed files** — local `git diff --name-status` over the same range:
  **49 files (24 added + 25 modified)**. Match.
- The remote hardening branches (WP-1…WP-14) and the constitution policy
  branch exist at the SHAs above; the four pinned governance blobs
  (constitutions, dataset_v23.py, P0_STATUS.md) verify at their pinned
  identities (see `01-constitution-reading/READING_NOTE.md`).

## What is NOT in this directory (lost; deliberately not reconstructed)

- **The N8 series** (4 logical commits; reported 506→545 test progression;
  per-residue altloc consistency, CSS mapping/HETATM census, 1PPE mmCIF
  equivalence, verdict precedence, AlphaFold pinning, runner provenance,
  CI isolation). Lost with the sandbox reset; never pushed. **No patch in
  this bundle represents it, and no patch here should be cited as N8.**
- **The local docs branch `df44aa6`** (N6 governance docs / 15-gate ledger).
  Lost; never pushed. The decision content is carried forward only as
  `AUDITOR-ADJUDICATED` entries in `04-decisions/OWNER_DECISIONS.md` with
  explicit provenance.
- **The prior evidence archive** (`b2d43f7f…`, 19,201,281 bytes, 102 or 77
  members). Lost; hash permanently unverifiable. Superseded by this bundle.

See `../08-lost-work-statement/LOST_WORK_REGISTER.md` for the full register
and the standing rules.

## Verification

For each series: `git apply --check` against the parent tree, or clone from
the corresponding bundle and `git log`/`git range-diff` the range. The
bundle-level verifier (`../verifier.sh`) re-verifies branch tips and blob
identities from the bundled git data without network access to GitHub.
