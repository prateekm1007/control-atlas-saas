#!/usr/bin/env bash
# Clean-checkout reproduction script for the Round-9 evidence bundle.
#
# Reproduces, from a fresh environment with network access:
#   1. read-only clone of github.com/prateekm1007/control-atlas-saas
#   2. verification of the four pinned governance blobs + branch tips
#   3. the full 40-target RCSB cohort audit (API metadata + coordinates +
#      v24 manifest digest comparison + PDB parse checks)
#   4. re-derivation of the item-level table and its totals
#   5. comparison of the reproduced totals against the bundled table
#
# Requires: bash, git, python3 (requests), curl, sha256sum, internet access.
# NOTE: this performs NO calibration, threshold derivation, verdict issuance,
# cohort change, or push. Read-only operations + local file writes only.
#
# Usage: bash reproduce-clean-checkout.sh [workdir]
set -uo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
WORK="${1:-$(mktemp -d)}"
mkdir -p "$WORK"; cd "$WORK" || exit 1
FAIL=0
note() { printf '%s\n' "$*"; }
bad()  { printf 'FAIL: %s\n' "$*"; FAIL=1; }

note "== [1/5] Clean clone (read-only) =="
git clone -q https://github.com/prateekm1007/control-atlas-saas.git repo \
    || { bad "clone failed"; exit 1; }
cd repo || exit 1
note "   cloned at $(git rev-parse HEAD)"

note "== [2/5] Pinned blobs and branch tips =="
git fetch -q origin science/p0-correctness-2026-10-19 \
    policy/engineering-constitution 2>/dev/null || true
chk() { got="$(git rev-parse "$2" 2>/dev/null)"; [ "$got" = "$3" ] \
    && note "   OK: $1" || bad "$1: $got != $3"; }
chk "constitution.md" "origin/main:constitution.md" "211ad2c5d4b40059d9f3f03de12e0701f9235bc7"
chk "ENGINEERING_CONSTITUTION.md" "origin/policy/engineering-constitution:ENGINEERING_CONSTITUTION.md" "b6bb35e84956d84a8c9d9e65734c212baf3ed075"
chk "dataset_v23.py" "origin/science/p0-correctness-2026-10-19:backend/calibration/dataset_v23.py" "3a5358374b2037b9475bd2d494754944485da5ac"
chk "P0_STATUS.md" "origin/science/p0-correctness-2026-10-19:docs/P0_STATUS.md" "22ca8ce9c0c79ba396e8a4569f419d9fa6f01d0a"
chk "science tip" "origin/science/p0-correctness-2026-10-19" "ebc1fd79f20b9a6b6a262a70ce6942ba069d19e9"
chk "wp15 tip (PR-16 head)" "origin/science/law-validity-wp15" "296f10c4f2c87df2003c1a9d0150edc0b54a13d9"

note "== [3/5] Extracting pinned inputs =="
mkdir -p "$WORK/audit"
git show origin/science/p0-correctness-2026-10-19:backend/calibration/dataset_v23.py \
    > "$WORK/audit/dataset_v23.py"
git show origin/science/p0-correctness-2026-10-19:backend/calibration/runs/v24/coordinate_manifest.json \
    > "$WORK/audit/coordinate_manifest_v24.json"
note "   extracted dataset_v23.py + v24 coordinate manifest"

note "== [4/5] Running the 40-target RCSB audit (fresh) =="
mkdir -p "$WORK/audit/audit-evidence/rcsb-api" "$WORK/audit/audit-evidence/coordinates"
sed -e "s|^BASE = .*|BASE = \"$WORK/audit\"|" \
    -e "s|EV = os.path.join(BASE, \"audit-evidence\")|EV = os.path.join(BASE, \"audit-evidence\")|" \
    "$HERE/09-scripts/rcsb_cohort_audit.py" > "$WORK/audit/run_audit.py"
python3 "$WORK/audit/run_audit.py" || { bad "audit run failed"; exit 1; }
sed -e "s|^EV = .*|EV = \"$WORK/audit/audit-evidence\"|" \
    "$HERE/09-scripts/fix_parse_pass.py" > "$WORK/audit/run_fix.py"
python3 "$WORK/audit/run_fix.py" || bad "fix pass failed"
sed -e "s|^EV = .*|EV = \"$WORK/audit/audit-evidence\"|" \
    "$HERE/09-scripts/adjudicate_table.py" > "$WORK/audit/run_adj.py"
python3 "$WORK/audit/run_adj.py" || bad "adjudication failed"

note "== [5/5] Comparing reproduced totals against the bundled table =="
python3 - "$WORK/audit/audit-evidence/n7_od16_40target_table.json" "$HERE/02-n7-od16-cohort-audit/n7_od16_40target_table.json" <<'PY' || FAIL=1
import json, sys
new = json.load(open(sys.argv[1]))["totals"]
old = json.load(open(sys.argv[2]))["totals"]
ok = True
for k in old:
    if new.get(k) != old[k]:
        print(f"FAIL: total '{k}' differs: reproduced {new.get(k)} vs bundled {old[k]}")
        ok = False
if ok:
    print("   OK: all reproduced totals identical to the bundled table:")
    for k in ("c1_descriptive_errors", "c2_method_mismatches",
              "c2_resolution_mismatches_strict", "c2_resolution_mismatches_tol001",
              "c3_nucleic_acid_only", "c3_mixed_protein_nucleic",
              "c4_parse_failures", "c5_coordinate_byte_mismatches",
              "any_metadata_defect"):
        print(f"     {k} = {old[k]}")
import sys as s
s.exit(0 if ok else 1)
PY

note ""
if [ "$FAIL" -eq 0 ]; then
    note "RESULT: REPRODUCTION COMPLETE — all checks and totals reproduced."
    note "Workdir: $WORK (raw API responses, coordinates, and tables retained)"
else
    note "RESULT: REPRODUCTION DIFFERS — inspect the failures above."
    note "(If RCSB revised an entry since 2026-10-19T20:01Z, C1/C2 columns may"
    note " legitimately differ; C5 byte mismatches would also appear. Compare"
    note " per-row evidence before treating a difference as a bundle defect.)"
fi
exit "$FAIL"
