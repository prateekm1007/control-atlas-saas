# Document Word Target — OD-21, UNCONFIRMED (Round 10, T4)

**Status of the target: UNCONFIRMED.** **No number is chosen** — neither
5,460 nor 5,470, nor any other.

## 1. What the two figures were

Prior-round transcripts referenced a documentation word target of "5,460
words" in one place and "5,470 words" in another. The discrepancy was
flagged for resolution in the Round-9 continuation directions ("resolve the
documentation's 5,460 versus 5,470 word-target discrepancy; preserve both
historical records; label the target self-chosen unless an authoritative
source establishes otherwise").

## 2. What the record actually shows (searches, both sides)

| Search | Performed by | Scope | Result |
|---|---|---|---|
| `git grep -E "5,?4[67]0"` over `*.md` `*.txt` `*.json` | coder, 2026-10-19T20:4xZ | `origin/main`, `origin/science/p0-correctness-2026-10-19`, `origin/integration/p0-hardening-2026-10-19`, `origin/policy/engineering-constitution` (all tracked files) | **no hit** for either figure |
| Full tracked-file search, all three relevant branches | auditor (Round 10, T4) | same class of scope | **no record of 5,460 or 5,470**; the only hit was a numeric false positive |

Neither figure exists in any tracked file in the repository. Both figures
live only in prior-session transcript claims (`CODER_REPORTED`, and the
prior sessions' environments are lost — see `08-lost-work-statement/`).
There is no authoritative source record establishing either number, and no
basis on which a third party could verify which (if either) was ever the
real target.

## 3. Disposition (auditor T4, verbatim-in-substance)

- **Do not pick either number.**
- **OD-21 opened:** "Document word target: confirm the number and its
  source requirement." (Register: `04-decisions/OWNER_DECISIONS.md`,
  Part 2; decision status OPEN; decided-by blank; not implemented.)
- **The documentation remains at its current count** — whatever document
  the target once referred to is left exactly as it is; no document is
  edited to reach any word count.
- **The target is labelled "unconfirmed" wherever referenced.**
- **This is not counted as an unmet engineering requirement.** An
  unconfirmed, source-less target cannot define "done" (EC §12: "not run"
  is never "passed"; a requirement that cannot be evidenced cannot gate).

## 4. Supersession note

Section 5 of `N3_COUNT_CORRECTION_v2.md` previously concluded the target
was "coder-selected, self-imposed." That conclusion is **superseded**: with
no surviving record of either number, even the "self-chosen" attribution
cannot be evidenced. The standing record is this document: **unconfirmed,
OD-21, no number chosen.** The v2 text is annotated in place (see the
supersession marker in that file) and preserved unchanged inside the r1
archive for history.

## 5. Closure

OD-21 closes only when the owner (or an authoritative source record)
confirms the number and its source requirement in writing, per the closure
protocol in the register (Part 6).
