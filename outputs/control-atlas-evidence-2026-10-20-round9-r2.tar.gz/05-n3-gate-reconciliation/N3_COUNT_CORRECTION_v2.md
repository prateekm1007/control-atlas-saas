# N3 / Gate-Ledger Count Correction — Version 2

**Why v2, and what happened to v1.** A version-1 count-correction document
was produced in the prior session. The prior sandbox was reset; the v1 bytes
are lost and **cannot be presented for byte-level comparison** — and per the
Constitution (§6: never invent counts; §13: no unevidenced claims) this
document does **not** claim v1 is unchanged, because that claim cannot be
evidenced from this environment. What v2 does instead is stronger where it
can be: every count below is re-derived this session from the **remote,
blob-pinned** `docs/P0_STATUS.md`
(`22ca8ce9c0c79ba396e8a4569f419d9fa6f01d0a` @
`science/p0-correctness-2026-10-19`, tip `ebc1fd7`), which is independently
verifiable by anyone with repository read access.

## 1. P0_STATUS.md counts (re-derived this session from the pinned blob)

| Count | Value | Derivation |
|---|---|---|
| Numbered items marked `[x]` (done) | **14** | items 3, 4, 5, 6, 7, 8, 9, 11, 12, 13, 14, 15, 17, 18 |
| Numbered items marked `[owner]` (blocked) | **2** | items 10 (pLDDT scope LAW-130/155/200), 16 (cohort rebuild) |
| Unnumbered owner actions | **5** | rotate Gemini key; set EC2 secrets (`TOSCANINI_API_KEYS`, `INTERNAL_CALLBACK_SECRET`, `ALLOWED_ORIGINS`, `GEMINI_API_KEY`); branch protection on main + Stability Gate; governance file location (Gate 1) + constitution decisions (Gate 2); approve any verdict-changing PR |

## 2. The two ledgers are different records, not a conflict

- **P0_STATUS.md** (remote, blob-pinned, verifiable) covers **items 3–18 of
  the 2026-10-19 audit directions** — an execution checklist for the P0
  correctness program, spanning engine correctness, AlphaFold acquisition,
  runner hardening, cohort prep, and hygiene, plus the owner-action tail.
- **The governance gate ledger** (15 gates: **2 BLOCKED, 12 OPEN,
  1 PARTIALLY_VERIFIED**) is a **separate record** maintained for the
  constitution/governance program. Its figures are quoted from the auditor's
  N3 statement; the ledger file itself lived on the lost local docs branch
  (`df44aa6`) and is **not verifiable from this environment** — its figures
  are recorded here as auditor-attested, neither re-verified nor altered.
- The two must not be merged, subtracted, or cross-totalled: 14+2+5 (P0
  program) and 15 (governance gates) count different objects. Any
  presentation that treats them as one ledger reproduces the original N3
  counting defect.

## 3. The 16 → 15 decisions/gates correction (preserved)

The earlier framing of "16 decisions/gates" is corrected to **15 governance
gates**, and the decision space is now carried by a separate register: the
**12 auditor-adjudicated decision areas** (D-1…D-12) in
`04-decisions/OWNER_DECISIONS.md`. Ledger: 15 gates (governance program) +
12 decision areas (this reconciliation round) + P0_STATUS's 16 numbered items
and 5 owner actions (execution program). Three records, three purposes, no
cross-sums.

## 4. pdf_qa wording (mandated phrasing, scoped)

Where the prior evidence set is described, the QA outcome is stated exactly
as: **"12 pass + 1 design warning."** No independent QA reproduction is
claimed: the underlying artifacts are not in the repository, and the prior
session's QA run is not re-executable from this environment. This wording
and its scope are normative for any future reference to that QA record.

## 5. The 5,460-word target (self-selected)

> **SUPERSEDED (Round 10, T4, 2026-10-20):** the conclusion below is
> superseded by `WORD_TARGET_OD-21_UNCONFIRMED.md`. With no tracked record
> of either 5,460 or 5,470 (auditor-verified and coder-verified), even the
> "self-chosen" attribution cannot be evidenced. The standing record:
> target **UNCONFIRMED**; **no number chosen**; **OD-21 opened**
> (confirm the number and its source requirement); the documentation stays
> at its current count; not an unmet engineering requirement. The text
> below is preserved for history (it is also preserved unchanged inside
> the r1 archive).

The 5,460-word documentation target referenced in prior rounds was a
**coder-selected, self-imposed target**, not a requirement from any
authoritative source (no governance document, audit direction, or owner
instruction specifies it). It is recorded as such unless the owner or auditor
issues an authoritative figure.

## 6. N4 roadmap availability (corrected record)

- The original roadmap document — "Calibration Roadmap Handoff — Experimental
  Structures to AlphaFold" — **is available in the auditor's environment**:
  53,837 bytes, SHA-256
  `27ecb2d6bcb6c479a92b5edde3aa869675990aa135adbe668f086d0af73aca4d`.
- The historical fact stands as recorded: **the coder sandbox lacked that
  file** during the relevant prior sessions (it was never present in the
  coder's working environments, including this one — verified this session:
  no file with that name or digest exists in the current sandbox or in the
  repository as cloned).
- **No byte-level comparison has been performed** between the auditor's copy
  and any coder-side copy (none exists), and none is claimed. If the owner
  wants a byte-level verification, the file must be delivered into a coder
  session and hashed there; until then the digest above is quoted from the
  auditor's record.

## 7. What changed vs v1, and epistemic status of each statement

| Statement | Status |
|---|---|
| P0_STATUS counts (14/2/5) | `MEASURED` this session from the pinned remote blob |
| 15-gate ledger figures (2/12/1) | `AUDITOR_ATTESTED` (ledger file lost; quoted, unaltered) |
| "Different records, not a conflict" | Re-derived and re-affirmed |
| pdf_qa "12 pass + 1 design warning" | Mandated wording preserved; `CODER_REPORTED` underlying run; no reproduction claimed |
| 5,460-word target self-selected | Re-affirmed |
| 16→15 correction | Preserved |
| N4 roadmap in auditor environment | `AUDITOR_ATTESTED` (digest quoted); coder-side absence re-verified this session; no byte comparison claimed |
| v1 document byte-stability | `NOT_CLAIMABLE` (v1 lost with sandbox reset; this document replaces it) |
