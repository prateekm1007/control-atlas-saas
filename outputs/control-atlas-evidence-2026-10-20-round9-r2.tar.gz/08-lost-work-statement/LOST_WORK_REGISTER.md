# Lost Work Register — Prior-Session Artifacts Not Recoverable From This Environment

**Purpose.** The Constitution (§6, §12.8, §13) forbids presenting unrun work
as done and unevidenced claims as fact. This register states plainly which
prior-session artifacts are **lost**, so that no future round accidentally
treats them as verifiable, and none of them is silently reconstructed as if
it were original history.

**Cause.** The coder sandbox was reset between sessions (fresh filesystem;
only a trivial initial commit remained; no prior scripts, branches, or
archives present). The prior session's local branches were never pushed
(remote governance forbade pushes), so reset = loss.

## Register

| # | Artifact | Prior-session claim (transcript) | Current status | Reconstruction policy |
|---|---|---|---|---|
| L-1 | N8 code series (4 logical commits; suite 506/5 → 545/5 reported) | per-residue altloc consistency; synthetic chimera tests; CSS mapping + modified-residue census; HETATM counting isolation incl. 1PPE PDB/mmCIF equivalence; verdict precedence; AlphaFetch pinning/security; package-install runner provenance; network-isolated CI + live RCSB probe | **LOST — NOT_REPRODUCIBLE.** Never pushed (auditor Round 10, T7: branch tip `e9985c6` — the per-residue altloc fix commit — **still absent from GitHub**; recorded as NOT PUSHED). No commits, diffs, test logs, or fixture hashes survive. The 545/5 and per-commit counts remain `CODER_REPORTED` only. Baseline 506/5 was independently established and remains checkable on remote branches. | **NOT reconstructed.** Re-implementing from a description would fabricate history the auditor explicitly required to be labeled original-vs-rebuilt; with zero surviving bytes there is nothing to rebuild faithfully. Any future N8-class work starts as a NEW proposal with fresh commits, logs, and digests. |
| L-2 | N7 paired-measurement logs/tables (48/48 measured, 2 AF fail-closed, 0 verdict changes, 0 coverage changes, 2 crambin law-value changes) | engine-stability comparison across two revisions on pinned inputs | **LOST — CODER_REPORTED.** Preserved as claims only, with narrowed conclusion (`03-n7-comparison/`). Consistency checks that remain possible are recorded there. | Not re-run (hard stop). If unblocked later, a NEW comparison on the corrected cohort supersedes it entirely. |
| L-3 | Evidence archive `control-atlas-evidence-2026-10-20.tar.gz` | 19,201,281 bytes; SHA-256 `b2d43f7fcbdca77a34d4512608689cb3dc80082f3debee2551ee03a2691f5145`; 102 manifested files (earlier statement: 77 members) | **LOST — NOT_VERIFIABLE.** The bytes are gone; the quoted hash can never be checked against anything. The member-count inconsistency (102 vs 77) is permanently unresolvable. | Superseded by THIS bundle (`control-atlas-evidence-2026-10-20-round9.tar.gz`), a different artifact with its own size/hash/manifest. The old hash is retired — no future document may cite it as evidence of anything. |
| L-4 | Local docs branch (N6 governance docs, incl. the 15-gate ledger) | proposed docs patch with manifest (source/target SHAs) | **LOST.** Never pushed; no remote ref. Auditor Round 10 (T7) states the docs branch tip is **`94b0f7c`**, **still absent from GitHub** — recorded as NOT PUSHED. The prior-session transcript had referenced an earlier tip `df44aa6`; both identifiers are recorded (the branch evidently advanced before loss); neither state is recoverable. The 15-gate ledger figures survive only as auditor-attested quotes (see `05-n3-gate-reconciliation/`). | Not reconstructed as "the" ledger. The OD register (`04-decisions/OWNER_DECISIONS.md`, rev 3) carries the decision content forward under explicit provenance, with the D-xx internal labels crosswalked to OD-xx. |
| L-5 | v1 count-correction document | N3 reconciliation v1 | **LOST.** Byte-stability of v1 is `NOT_CLAIMABLE`. | v2 (this bundle) re-derives every count from the remote-pinned blob. |
| L-6 | Prior reading notes / session markers | constitution-reading evidence of prior sessions | **LOST** (and per Round-9 direction 1, no longer load-bearing: this session re-read both constitutions from scratch; see `01-constitution-reading/`). | Superseded by the current-session reading note. |

## Standing rules extracted from this loss

1. **Evidence that exists only in a transcript is `CODER_REPORTED`, forever,
   unless the bytes surface.** This bundle's verifier scripts exist so that
   everything claimed *new* this session is independently checkable instead.
2. **Durable archives must be delivered, not described.** The Round-8
   failure mode (claiming a 19.1 MB archive nobody could hash) is what this
   register exists to prevent recurring.
3. **No push was possible or attempted at any point** (no credentials; hard
   stop in force). Remote branches verified this session are the only shared,
   durable history — which is why this bundle ships them as git bundles with
   pinned tips (`06-git-bundles/`). The Round-10 record (T7): the docs
   branch (`94b0f7c`) and the N8 branch (`e9985c6`) remain absent from
   GitHub — **not pushed**; OD-15 (incident) stays OPEN; no pushes and no
   new remote branches were created in either session.
