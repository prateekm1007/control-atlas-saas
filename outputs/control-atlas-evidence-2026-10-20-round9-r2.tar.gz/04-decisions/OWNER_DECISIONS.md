# OWNER_DECISIONS — Decision Register (Round 10, rev 3)

**Provenance.** The decision space is numbered **OD-01 … OD-21** plus owner
actions **A-01 … A-06**. OD-01 … OD-16 are the auditor's pre-existing
register and are kept **unchanged** (Round-10 direction T2). OD-17 … OD-21
are new items recorded this round from the auditor's Round-9/Round-10
directives. Internal labels **D-1 … D-12** (used by the Round-9 register,
preserved in the original r1 archive) are retained **only** as internal
labels, crosswalked in Part 3. **No number is ever reused.**

**Status discipline (binding, per auditor T3).** Two distinct statuses:
- **Decision status** — OPEN (awaiting the owner's written decision),
  DECIDED, or superseded. OD-17 … OD-21 are **directives, not decisions**:
  each is recorded **OPEN**, with **decided-by: (blank)** and
  **decided-date: (blank)**, until the owner writes a decision.
- **Implementation status** — whether repo/security gate/release actually
  implements it. **None of OD-17 … OD-21 is implemented**, and none may be
  implemented until the owner decides (T3). A reconciled or recorded
  decision never means the code, security gate, or release is accepted.

**Repo placement.** This register is delivered in the evidence bundle. Its
intended home is `docs/decisions/OWNER_DECISIONS.md` in the repository; that
placement is **blocked** (hard stop: no pushes; the local docs branch was
never pushed — see Part 5). The auditor's checklist item
"`docs/decisions/OWNER_DECISIONS.md` on GitHub" therefore remains open.

---

## Part 1 — Auditor's register: OD-01 … OD-16 (UNCHANGED)

The authoritative content of OD-01 … OD-16 lives in the auditor's register.
The coder records below **only** what the auditor has stated in directions
and checklists; where the auditor has not delivered a number's content, that
is marked **"not stated by auditor"** — nothing is invented. These entries
are `AUDITOR_ATTESTED` unless a pinned remote blob corroborates them.

| ID | Subject (as stated by the auditor) | Status known to coder | Corroborating record |
|---|---|---|---|
| OD-01 | Canonical governance file (location/decision) | open — owner-gated (auditor checklist: "Canonical governance file decided (OD-01)" unchecked) | P0_STATUS owner actions (blob `22ca8ce9…`): "governance file location (Gate 1)" |
| OD-02 | Constitution decisions | not stated in full; owner-gated per P0_STATUS tail | P0_STATUS owner actions: "constitution decisions (Gate 2)" |
| OD-03 | pLDDT scope (LAW-130/155/200 set) | open — owner-gated (auditor checklist: "[owner] pLDDT scope for LAW-130, 155, 200 (OD-03, OD-04)") | P0_STATUS item 10; `evidence/item-10/DECISION_REQUIRED.md` on the science branch |
| OD-04 | pLDDT scope (second item of the pair) | open — owner-gated (same checklist row) | same |
| OD-05 | **not stated by auditor.** The auditor's retained disposition areas — verdict precedence, LAW-120 containment, certificate policy, audit IDs, tenant-scoped history access, runner provenance, CSS semantics — are distributed across OD-05…OD-16; the exact assignment was not delivered. No content invented. | not stated | — |
| OD-06 | not stated by auditor | not stated | — |
| OD-07 | not stated by auditor | not stated | — |
| OD-08 | not stated by auditor | not stated | — |
| OD-09 | not stated by auditor | not stated | — |
| OD-10 | Cohort rebuild (eligibility, sample size, criteria, family-disjoint splits) | open — prerequisite chain to OD-18/OD-19 (auditor checklist: "Cohort rebuilt (OD-10 to OD-12, OD-18, OD-19)") | P0_STATUS item 16 (commit `ebc1fd7`); OD-16 addendum v2 in this bundle |
| OD-11 | P0DTC2 cohort disposition (follow migrated AFDB entity vs replace) | open — owner-gated (auditor checklist: "[owner] P0DTC2 … (OD-11, OD-12)") | P0_STATUS item 14 (commit `9de4fff`); v24 manifest AF failures |
| OD-12 | P62988 cohort disposition (UniProt-inactive entry) | open — owner-gated (same row) | same |
| OD-13 | AlphaFold version/entity pinning for calibration | open — implementation claimed on lost local branch, **not on GitHub** (auditor checklist: "[c] Version pin for calibration (OD-13), not on GitHub") | P0_STATUS items 11–13 (commit `9de4fff`, on-GitHub part) |
| OD-14 | V4 approval / verdict-change table | open — owner-gated (auditor checklist: "[owner] OD-14 V4 approval"; "Verdict-change table approved (OD-14)") | `calibration_v24_SUPERSEDED.md`; LAW-120 independent verification JSON |
| OD-15 | Incident record | **OPEN** (auditor T7: "OD-15 (incident) stays OPEN") | — |
| OD-16 | Merge and deploy sequence | open — owner-gated (auditor checklist: "[owner] OD-16 merge and deploy sequence") | hard-stop record on PR #16 (open/unmerged, 49 files) |

**Numbering-collision resolution (auditor T2, recorded verbatim-in-substance).**
The Round-9 continuation directions used the labels "D-4" (cohort
eligibility), "D-11" (stratum population), and "OD-16" (metadata integrity),
which collided with (a) the auditor's own OD-16 (merge and deploy sequence)
and (b) the r1 register's internal D-numbering (D-1…D-12). Resolution, per
the auditor: keep OD-01…OD-16 unchanged; metadata integrity becomes **OD-17**;
cohort eligibility becomes **OD-18**; stratum population becomes **OD-19**;
NMR subclass becomes **OD-20**. No number reused.

---

## Part 2 — New items recorded this round: OD-17 … OD-21 (all OPEN)

> These are **auditor directives recorded for owner decision — they are not
> decisions** (T3). Decided-by and decided-date are blank. None is
> implemented. The auditor's dispositions are quoted in substance; the
> underlying owner acceptance is NOT asserted.

### OD-17 — Cohort metadata integrity (quarantine)

- **Decision status: OPEN.** decided-by: — ; decided-date: —
- **Auditor disposition.** Quarantine the historical v23 cohort metadata
  from calibration and threshold derivation until a corrected,
  source-backed cohort proposal is reviewed. Preserve `dataset_v23.py`
  (blob `3a5358374b2037b9475bd2d494754944485da5ac`) and historical
  calibration outputs unchanged. Do not silently correct historical inputs,
  replace targets, or represent matching coordinate bytes as proof that the
  cohort labels are valid. The entire historical v23 cohort is quarantined
  for calibration purposes pending reconciliation; the eight entries
  labelled clean by the coder remain candidates, **not** an approved
  replacement calibration cohort.
- **Rationale / evidence.** Row-derived audit (this bundle, `02-`):
  22/40 descriptive errors (21 identity + 1 state), 5/40 method, 24/40
  strict resolution (23/40 at 0.01 Å), 2/40 non-protein-only (1I0T DNA-only;
  1DDL protein+RNA), 0 parse failures, 0/40 coordinate-byte mismatches vs
  the v24 manifest — 32/40 rows carry ≥1 metadata defect. Byte-match
  establishes acquisition stability only, never label validity.
- **Implementation status: NONE (directive).** The quarantine is *documented*
  (this register + hard stop); no repository, dataset, or calibration change
  was made or is authorized.
- **Technical closure criteria.** Owner approves the reconciliation
  (corrected-cohort proposal v2, classes A–D); corrected cohort built per
  the version-1 order of operations (owner criteria → digest-pinned build →
  held-out split committed before measurement); v23 metadata retired from
  all decision inputs; historical files preserved unchanged.

### OD-18 — Cohort eligibility (1I0T, 1DDL)

- **Decision status: OPEN.** decided-by: — ; decided-date: —
- **Auditor disposition.** `1I0T` is ineligible for the protein-only
  calibration cohort because it is DNA-only (Z-DNA at 0.60 Å). `1DDL` is
  excluded from the core calibration cohort until the protocol expressly
  supports mixed protein–RNA structures and defines their measurement
  scope. Keep both in a separate, explicitly classified audit set.
- **Rationale / evidence.** RCSB-verified entity composition in the
  item-level table (`02-`); the tracked artifact
  `independent_recompute_20_of_40.json` (blob `6cda70e2…`) independently
  lists exactly 1I0T and 1DDL as the two LAW-170-blocked structures of the
  recorded v23 run.
- **Implementation status: NONE (directive).**
- **Technical closure criteria.** Owner-approved eligibility rules that
  exclude non-protein-only and mixed-composition structures from the core
  cohort absent explicit protocol support; an explicitly classified audit
  set containing both entries; recorded in the approved cohort proposal.

### OD-19 — Stratum population

- **Decision status: OPEN.** decided-by: — ; decided-date: —
- **Auditor disposition.** Do not choose or infer new stratum quotas from
  the flawed historical metadata. Recompute strata only after identity,
  modality and resolution reconciliation; prespecify sample-size
  feasibility and uncertainty requirements before outcomes are reviewed.
- **Rationale / evidence.** The recorded strata are built from defective
  labels (post-correction, the cryo-EM stratum loses 3 of 8 entries to
  X-ray/ssNMR — see the OD-16 addendum v2, §strata).
- **Implementation status: NONE (directive).**
- **Technical closure criteria.** Prespecified stratum definition document
  (post-reconciliation), with sample-size feasibility and uncertainty
  requirements, committed and approved before any measurement or outcome
  review.

### OD-20 — NMR subclass handling

- **Decision status: OPEN.** decided-by: — ; decided-date: —
- **Auditor disposition.** Keep NMR separate from resolution-based
  X-ray/cryo-EM strata. No pooled resolution-threshold derivation from NMR
  ensembles until model selection, ensemble treatment and applicable laws
  are prespecified. NMR structures may remain exploratory audit inputs when
  their identities and scope are valid.
- **Rationale / evidence.** 1RVS and 2N0A are solid-state NMR (recorded
  under `nmr` implying solution NMR — method mismatches in the item-level
  table); ensemble/model-selection semantics for NMR are undefined in the
  current protocol.
- **Implementation status: NONE (directive).**
- **Technical closure criteria.** Prespecified NMR policy (model selection,
  ensemble treatment, applicable laws) approved before any NMR-involving
  calibration; NMR excluded from pooled resolution strata until then.

### OD-21 — Document word target

- **Decision status: OPEN.** decided-by: — ; decided-date: —
- **Auditor disposition (T4).** "Document word target: confirm the number
  and its source requirement." The transcript figures 5,460 and 5,470 are
  **unresolved**: the auditor searched every tracked file on the three
  relevant branches and found **no record of either number** (the only hit
  a numeric false positive); the coder's independent `git grep` across
  `origin/main`, `origin/science/p0-correctness-2026-10-19`,
  `origin/integration/p0-hardening-2026-10-19`, and
  `origin/policy/engineering-constitution` (2026-10-19T20:4xZ) found the
  same. **No number is chosen.** The target is labelled **"unconfirmed."**
  The documentation remains at its current count; this is **not** an unmet
  engineering requirement. See
  `05-n3-gate-reconciliation/WORD_TARGET_OD-21_UNCONFIRMED.md`.
- **Implementation status: NONE (directive).**
- **Technical closure criteria.** Owner (or an authoritative source record)
  confirms the number and its source requirement in writing; the register
  and the affected documentation are then updated in one reviewed change.

---

## Part 3 — Crosswalk: internal D-xx labels (r1 register) → OD-xx

The r1 register's twelve `AUDITOR-ADJUDICATED` areas (full text preserved in
the original r1 archive: `control-atlas-evidence-2026-10-20-round9.tar.gz`,
`04-decisions/OWNER_DECISIONS.md`) keep their D-numbers as **internal labels
only**. Mappings below are stated **only** where the auditor's checklist or
directions state them; otherwise "not stated" — the internal label is
retained and no OD number is guessed.

| Internal label | Subject (r1 register) | OD mapping |
|---|---|---|
| D-1 | Verdict precedence | not stated by auditor |
| D-2 | LAW-120 / V4 containment and threshold treatment | OD-14 (auditor checklist: "OD-14 V4 approval") |
| D-3 | LAW-130/155/200 scope; LAW-190/210/220/230 status | OD-03/OD-04 for the pLDDT pair (checklist); LAW-190…230 mapping not stated |
| D-4 | Cohort and split prespecification | OD-10 (checklist: "Cohort rebuilt (OD-10 to OD-12 …)"); elaborated by OD-18/OD-19 |
| D-5 | P0DTC2 / P62988 identity records | OD-11 and OD-12 (checklist) |
| D-6 | AlphaFold version pinning | OD-13 (checklist: "Version pin for calibration (OD-13)") |
| D-7 | Certificate and audit record policy | not stated by auditor |
| D-8 | Audit IDs / tenant-scoped history | not stated by auditor |
| D-9 | Runner provenance | not stated by auditor |
| D-10 | CSS semantics and residue ordering | not stated by auditor |
| D-11 | v23 cohort metadata quarantine | **OD-17** (T2) |
| D-12 | Credentials, cloud secrets, branch protection | owner actions A-01…A-04 (checklist); OD mapping not stated |

**Collision note.** The auditor's Round-9-continuation message itself used
"D-4" and "D-11" as labels for cohort eligibility and stratum population.
Those two auditor labels are now **OD-18** and **OD-19** respectively (T2);
they are NOT the r1 register's D-4 (cohort and split) or D-11 (metadata
quarantine), which map to OD-10 and OD-17. Both label spaces are preserved
here to prevent any future conflation.

---

## Part 4 — Owner actions A-01 … A-06

Operational actions requiring owner execution with published (redacted)
verification evidence. The coder records evidence only after it exists
(EC §13; EC §3 credential rule).

| ID | Action | Status |
|---|---|---|
| A-01 | Revoke and reissue the PAT (credential in Git history: compromised until issuer confirms revocation) | open — owner-executed; no evidence to date |
| A-02 | Rotate the Gemini API key (still present in `main` HEAD tree per P0_STATUS) | open — owner-executed; no evidence to date |
| A-03 | Set EC2 production secrets (`TOSCANINI_API_KEYS`, `INTERNAL_CALLBACK_SECRET`, `ALLOWED_ORIGINS`, `GEMINI_API_KEY`) | open — owner-executed; no evidence to date |
| A-04 | Branch protection on `main` (require the Toscanini Stability Gate; disable direct pushes) | open — owner-executed; no evidence to date |
| A-05 | Merge the Engineering Constitution (canonical governance per OD-01/OD-02) | open — owner-gated |
| A-06 | **NEW (T8).** Decide keep-or-delete for the stale legacy branch `fix/c2-api-key-enforcement` | open — recorded this round; see below |

**A-06 record (T8).** `fix/c2-api-key-enforcement` is February 2026 work by
the owner (tip `2d4de2f`, 2026-02-23, "C2: API key enforcement active
(TOSCANINI_API_KEY set in .env, not committed)"). The auditor states it
diverged by 543 files; coder-measured this session from the read-only
clone: the branch is **0 commits ahead / 68 commits behind `origin/main`**
(`git rev-list --left-right --count`), direct tree diff
`origin/main…origin/fix/c2-api-key-enforcement` = **95 files changed, 456
insertions(+), 14,313 deletions(−)** (main has grown past it; the branch is
stale, not advancing). The two divergence figures are recorded side by side
without reconciliation — they measure different comparisons; the auditor's
543-file figure is quoted from their record. The branch is **not part of
P0**, was **not touched**, and its disposition is the owner's decision
(A-06).

---

## Part 5 — Release hard stop and not-pushed record (T7)

1. **Hard stop in force.** PR #16 (`science/law-validity-wp15` @ `296f10c`
   → `integration/p0-hardening`) is open/unmerged, 49 changed files, no
   Task 32 artifacts in its diff; the hard-stop comment remains active.
   This session's fresh `git fetch --all --prune` (2026-10-19T20:47Z,
   exit 0) reports **no ref movement on any audited branch and no new
   remote branch**. `fix/c2-api-key-enforcement` predates this audit
   (February 2026) and is not new work.
2. **Not pushed — local docs branch.** Tip **`94b0f7c`** (auditor-stated,
   Round 10). Absent from GitHub. The prior-session transcript had
   referenced an earlier docs-branch tip `df44aa6` (recorded in the
   lost-work register, L-4); both identifiers are recorded — the branch
   evidently advanced before loss, and neither state is recoverable.
   **Recorded as NOT PUSHED.**
3. **Not pushed — N8 work branch.** Tip **`e9985c6`** (auditor-stated,
   Round 10; the per-residue altloc fix commit, first of the N8 series).
   Absent from GitHub; the full series (4 logical commits, suite counts
   506/5 → 545/5 as reported) is lost with the sandbox reset (lost-work
   register L-1). **Recorded as NOT PUSHED.**
4. **This session: no pushes, no new remote branches, no merges, no
   deployments** (read-only clone; no credentials; hard stop respected).
5. **OD-15 (incident) stays OPEN** (auditor T7).

---

## Part 6 — Closure protocol (T10, recorded verbatim-in-substance)

When the owner answers an OD in writing:

1. Create `docs/decisions/OD-<id>-<date>.md` carrying the owner's written
   decision and its exact scope.
2. Update this register: set decided-by, decided-date, decision status
   (DECIDED/superseded), and link the decision document.
3. Implement **only DECIDED items**; nothing is implemented on the strength
   of a directive or a recording (T3).
4. Run the CI sequence exactly as the Engineering Constitution requires
   (checks on the exact merge candidate; EC §7), never weakened for green.
5. Write evidence under `evidence/<item>/` with exact commands, SHAs, and
   counts (EC §6, §14).
6. Update `docs/P0_STATUS.md` for the affected items.
7. Hand the complete bundle (patches, logs, test results, decision record)
   to the auditor for independent verification.

---

## Register-level notes

1. **Three records, three purposes, no cross-sums** (unchanged from the r1
   register): the auditor's 15-gate governance ledger (2 BLOCKED / 12 OPEN /
   1 PARTIALLY_VERIFIED, auditor-attested; ledger file lost — L-4); this
   OD/A register; and P0_STATUS's 16 numbered items + 5 owner actions
   (execution checklist, blob-pinned). The r1 note about "12
   auditor-adjudicated decision areas (D-1…D-12)" described the r1
   register's internal labels, not the OD space.
2. **No silent status conversions.** No owner-blocked item is upgraded to
   accepted; recording an auditor disposition never asserts owner approval
   (auditor: "These are auditor dispositions, not an assertion that the
   repository owner has personally signed an approval").
3. **Decision ≠ implementation**, always. Every implementation rides on
   unmerged branches or is not yet begun; nothing in this register
   authorizes release activity while the hard stop is in force.
