# r2 Changelog — Round-10 Auditor Tasks T1–T10

**Base:** r1 archive `control-atlas-evidence-2026-10-20-round9.tar.gz`
(22,560,251 bytes, SHA-256 `42d8e881…`, 182 members, 165 manifested files).
**Result:** r2 archive `control-atlas-evidence-2026-10-20-round9-r2.tar.gz`
(exact size/hash/member counts in the delivery message and `MANIFEST.sha256`).
The r1 archive is preserved byte-identical and remains delivered; every r1
file not listed below is carried into r2 unchanged.

| Task | Requirement (auditor Round 10) | Change made in r2 |
|---|---|---|
| **T1** | One counting convention: bytes, UTF-8 characters, whitespace-split words, locale pinned; same convention everywhere; remove non-reproducible counts; label which convention each number uses | `verifier.sh`: `export LC_ALL=C.UTF-8` + `LANG=C.UTF-8` before any counting; §4 now checks **bytes / chars / words / lines** with words = whitespace split (**84** domain, **2,784** engineering — verified against `wc -w` this session); every count labelled by convention. `01-constitution-reading/READING_NOTE_session2_2026-10-20.md` §2a states the convention table; the numbers 11/12/9 and 178/179/129 are now always labelled **line counts (LF / split-elements / non-blank), never words**. No count in the bundle is non-reproducible under the pinned convention |
| **T2** | Resolve ID collisions: keep OD-01…OD-16; metadata integrity → OD-17; cohort eligibility → OD-18; stratum population → OD-19; NMR subclass → OD-20; D-xx stays internal with crosswalk; never reuse a number | `04-decisions/OWNER_DECISIONS.md` **rev 3**: Part 1 = OD-01…OD-16 unchanged (fragments as stated by the auditor; unstated content marked, nothing invented); Part 2 = OD-17…OD-21; Part 3 = D-1…D-12 → OD-xx crosswalk (mappings stated only where the auditor stated them) incl. the collision note distinguishing the auditor's Round-9 "D-4"/"D-11" labels from the r1 register's D-4/D-11 |
| **T3** | OD-17…OD-20 are directives, not decisions: mark OPEN, decided-by and date blank, implement none | Part 2: every entry carries "Decision status: OPEN. decided-by: — ; decided-date: —" and "Implementation status: NONE (directive)". No implementation performed anywhere in this round |
| **T4** | Word target unresolved: no tracked record of 5,460/5,470; do not pick either number; add OD-21; keep the document at its current count; label the target "unconfirmed" | New `05-n3-gate-reconciliation/WORD_TARGET_OD-21_UNCONFIRMED.md` (both sides' searches recorded; no number chosen; UNCONFIRMED; not an unmet engineering requirement). `N3_COUNT_CORRECTION_v2.md` §5 annotated as SUPERSEDED in place (text preserved). OD-21 recorded in the register Part 2 |
| **T5** | Correct "20 of 40": it was the auditor's un-recomputed bound; tracked artifact shows 0 of 40 (38 LAW-120@10°, 2 LAW-170: 1I0T, 1DDL); cite the artifact; label v23 values historical; replace "20 of 40" everywhere | New `02-n7-od16-cohort-audit/COUNT_RECONCILIATION_ALL_CLAIMS.md` (cites blob `6cda70e2…` @ `ebc1fd7`; historical labels; retracts the r1 §2 explanation of "20"); r1 `20-40_vs_23-40_RECONCILIATION.md` **removed** (preserved inside r1); `N7_OD16_DISCREPANCY_REPORT.md` §6 corrected in place; README headline updated. Remaining "[20/40]" tokens in `reproduction-log.txt` are **row indices** (row 20 of 40), not claims — left untouched as a historical log |
| **T6** | Make the archive independently checkable through a durable route; include manifest, SHA-256, verifier | r2 delivered via the audit environment's download channel with exact size + SHA-256; manifest + verifier inside; `README.md` "Delivery route" section records the channel and why a GitHub release asset is not possible (no credentials; hard stop). Git bundles carry the remote history verifiably |
| **T7** | Record the hard stop: no pushes, no new remote branches; docs branch (`94b0f7c`) and N8 branch (`e9985c6`) absent from GitHub — record as not pushed; OD-15 stays OPEN | `04-decisions/` Part 5 (not-pushed record, no-op fetch evidence, OD-15 OPEN); `08-lost-work-statement/LOST_WORK_REGISTER.md` L-1/L-4 amended with the auditor-stated tips and standing rule 3 extended |
| **T8** | Record the stale legacy branch `fix/c2-api-key-enforcement` (Feb 2026 owner work, diverged, not P0); add A-06; do not touch it | `04-decisions/` Part 4 A-06: tip `2d4de2f` (2026-02-23, owner); auditor-stated 543-file divergence quoted alongside coder-measured facts (0 commits ahead / 68 behind `origin/main`; direct tree diff 95 files, +456/−14,313) — both recorded, no forced reconciliation; branch untouched |
| **T9** | Sequence evidence: fetch time, read time, first-edit time; read must precede first edit | `01-constitution-reading/READING_NOTE_session2_2026-10-20.md` §0: fetch 2026-10-19T20:47Z → blob dump 20:48:56Z → full read 20:48–20:49Z → counts 20:49:19Z → **first edit 20:51:00Z** (filesystem mtime captured via `stat` before any later edit). All Round-10 edits occur after the read |
| **T10** | Close the loop: owner-written OD decisions → `docs/decisions/OD-<id>-<date>.md`, register update, implement only DECIDED items, exact CI sequence, evidence under `evidence/<item>/`, P0_STATUS update, hand bundle to auditor | `04-decisions/` Part 6: the closure protocol recorded verbatim-in-substance, seven steps |

**Also this round (not a T-task):** a suspected `[main.bundle]=` corruption in
`verifier.sh`'s TIPS array was investigated — hexdump proved the file
correct (`[m` had been swallowed by terminal-escape rendering in earlier
displays, not present in bytes); the r1 verifier passes as shipped. No
change required; recorded here so the investigation is not repeated.

**Constitutional basis for this revision:** EC §1 (conflict rule), §2
(reading before edits — §0 sequence), §4 (status discipline), §6 (counts
with commands), §11 (incident record preserved), §13 (no unevidenced
claims), §14 (task artifacts). Domain invariants OBS-153 / CRIT-154 remain
ACTIVE and untouched (not exercised: documentation-only round).
