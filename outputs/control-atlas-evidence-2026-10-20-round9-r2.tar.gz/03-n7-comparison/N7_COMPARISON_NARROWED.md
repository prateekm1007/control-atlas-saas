# N7 Paired Comparison — Preserved With Narrowed Conclusion

**Status of claims herein:** the N7 paired-comparison *transcript figures* are
`CODER_REPORTED`. The prior session's result tables, scripts, and logs were
lost with the sandbox reset (see `08-lost-work-statement/`); they are not
reproducible from this environment and are preserved below **as recorded
claims only**. Nothing in this document asserts those figures as verified
fact, and no re-measurement was attempted (hard stop in force: no calibration,
no v25, no threshold work, no use of the quarantined dataset).

## 1. The transcript figures (CODER_REPORTED, preserved verbatim)

Per the prior-session transcript as summarized in the audit record:

- 48 structures were measured on each of the two compared code revisions
  (the pinned v23/v24 input set: 50 targets minus 2 AlphaFold failures).
- Two AlphaFold targets failed closed (acquisition failure represented as
  explicit non-success, not as a verdict).
- No verdict changed between the revisions.
- No coverage changed between the revisions.
- Law values changed for two crambin structures (1EJG and 3NIR).

Consistency checks possible this session (weak, and labeled as such):

- The v24 coordinate manifest (remote, pinned) records 40/50 acquired and
  10/50 failed — all ten failures are AlphaFold entries 404ing on the legacy
  `model_v4` URL. The acquisition repair (P0 item 11, metadata-first lookup,
  verifiable in the remote history at `9de4fff`) plausibly converts 8 of
  those 10 into successes, leaving 2 fail-closed cases (P0DTC2 migrated
  entity; P62988 UniProt-inactive) — which matches the transcript's
  "48 measured, 2 failed closed" *arithmetically*. This is consistency, not
  reproduction: no measurement was run.
- The two crambin structures named by the transcript (1EJG, 3NIR) are exactly
  the two entries this session's OD-16 audit independently confirms as
  crambin (0.54 Å and 0.48 Å). The law-value changes the transcript
  attributed to them are consistent with identical molecules entering the
  comparison under different recorded metadata; the underlying values remain
  unverified (logs lost).

## 2. Narrowed conclusion (as directed)

**If and only if the N7 comparison is eventually reproduced from accessible
logs, it is admissible exclusively as software-behavior evidence, conditional
on the pinned input bytes.** Specifically:

1. What a reproduction would support: that the compared code revisions
   produce the same verdicts and coverage on the *same pinned input bytes*
   — i.e., engine mechanical stability across the changes under test.
2. What it would NOT support, even if fully reproduced:
   - validity of the cohort *composition* (32/40 rows carry metadata defects
     per the OD-16 audit);
   - validity of the cohort *labels* (22/40 descriptions incorrect; 5/40
     methods; 24/40 resolutions);
   - validity of the *stratification* (the recorded strata are built from the
     defective labels; after correction the cryo-EM stratum loses 3 of 8
     entries to X-ray/ssNMR);
   - *suitability for calibration* (OD-16 quarantine: the v23 cohort metadata
     is not valid input for calibration or threshold selection).
3. Byte-stability of the inputs (0/40 coordinate mismatches vs the v24
   manifest, verified this session) makes the "conditional on pinned input
   bytes" clause *checkable* — but input-byte stability is an acquisition
   property, not a scientific-suitability property.

## 3. Mandatory separation of columns in any future report

Any future presentation of N7 or successor comparisons must report, in
separate columns, never merged:

| Column | Content | Status of this session's data |
|---|---|---|
| Mechanical engine differences | verdicts, coverage, law values, honest-status transitions across code revisions on pinned bytes | `CODER_REPORTED` (transcript figures above; logs lost) |
| Cohort-data validity | identity/method/resolution/eligibility correctness of the cohort itself | `MEASURED` this session (`02-n7-od16-cohort-audit/`) |

## 4. Prohibitions restated (binding)

- No v25 execution; no threshold derivation; no calibration use of the
  quarantined dataset; no held-out evaluation; no cohort change; no
  golden-artifact regeneration (hard stop, PR #16, verified open/unmerged
  2026-10-19T20:15Z this session).
- The N7 figures must not be cited as validation of the cohort, of LAW
  semantics, or of any threshold — including the historical 18° LAW-120
  value (see the LAW-120/V4 decision in `04-decisions/OWNER_DECISIONS.md`).
- 2LYZ and 1PPE historical results remain diagnostic-only per the same
  decision. (Note: this session's audit additionally found 1PPE's recorded
  identity — "Porcine elastase" — is incorrect; the acquired structure is
  bovine β-trypsin + CMTI-I. Any historical result labeled "1PPE elastase"
  is doubly non-authoritative: diagnostic-only *and* mislabeled.)

## 5. Path to unblocking (owner-gated)

1. Owner approves the OD-16 reconciliation and cohort-v2 addendum
   (`02-n7-od16-cohort-audit/cohort_v25_proposal_v2_OD16_addendum.md`).
2. Cohort rebuilt per the version-1 order of operations (owner criteria →
   digest-pinned build → held-out split committed before measurement).
3. Only then may a *new* paired comparison run on the corrected cohort, with
   logs, scripts, and result tables committed to a reviewable branch before
   any claim is made from them.
